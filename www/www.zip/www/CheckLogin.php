<?php
  if(!isset($_SESSION['IsLogin']))
  {
	   redirect("Login.php"); 
  }


?>