<?php 
$Host='localhost';
$Username='root';
$Password='';
$DB='electioncommission';

// error_reporting(0);
$con=mysqli_connect($Host,$Username,$Password,$DB);
?>
