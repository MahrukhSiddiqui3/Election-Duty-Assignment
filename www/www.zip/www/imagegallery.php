


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta charset="utf-8" /><title>
	ECP - Election Commission of Pakistan
</title><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--Custom Css-->
    <link href="adminw/css/custom.css" rel="stylesheet" type="text/css" />
    <!--Bootstrap Css-->
    <link href="adminw/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!--Bootstrap Responsive Css-->
    <link href="adminw/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
    <!--Color Css-->
    <link href="adminw/css/color.css" rel="stylesheet" type="text/css" />
    <!--Font Awesome Css-->
    <link href="adminw/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!--Fevicon-->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <!--Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Slab:300,400,700" rel="stylesheet" type="text/css" /><link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
    <!--Bxslider Css-->
    <link href="adminw/css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
    <!--Pretty Photo Css-->
    <link rel="stylesheet" href="adminw/css/prettyPhoto.css" type="text/css" media="screen" />
    <!--Html 5 Js-->
    <script src="adminw/js/html5.js" type="text/javascript"></script>
    <!-- Color Css Files Start -->
    <link rel="alternate stylesheet" type="text/css" href="adminw/css/color-red.css" title="styles1" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-red.css" title="styles1" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-skyblue.css" title="styles2" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-orange.css" title="styles3" media="screen" /><link rel="stylesheet" type="text/css" href="adminw/css/color-green.css" title="styles4" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-blue.css" title="styles5" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-brown.css" title="styles6" media="screen" />
    <!-- Color Css Files End -->
    <!-- Progress bar -->
      



    
    <link href="adminw/css/EventsCSS.css" rel="stylesheet" type="text/css" />
  <script>
      var uploadedFilesCount = 0; var isEditMode; function validateRadUpload(source, e) {
          // When the RadGrid is in Edit mode the user is not obliged to upload file. 
          if (isEditMode == null || isEditMode == undefined) {
              e.IsValid = false;
              if (uploadedFilesCount > 0) {
                  e.IsValid = true;
              }
          }
          isEditMode = null;
      }
      function OnClientFileUploaded(sender, eventArgs) {
          uploadedFilesCount++;
      }
  </script>


    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
    <script type="text/javascript">// <![CDATA[
        $(function () {
            var listval = $('#list1')[0].offsetTop; $(document).scroll(function () {
                var topval = $(document).scrollTop(); if (topval >= listval) {
                    $('#list1').addClass('fixed');
                } else {
                    $('#list1').removeClass('fixed');
                }

            });

        });
        // ]]>
    </script>
    <style type="text/css">
#list1
{
	
	z-index: 1000;
}
.fixed{
position:fixed;
width: 100%;
top: 0px;
}
</style>
<link href="/WebResource.axd?d=iDaWiXY8DjvJoSvP_7FgB_c5mtcSoJ-V6g76Jj5h7Vd8ohuvP2iIN-BUPjvT67F9EGGz0-0J8UtE9lH8vX3pjSz1S-ofjqrNFaoQjjkzJKK5Sgz7sjVWQUoIB4hde-al_Ce0Zx3NLEsg9YxWUFQuTA2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=LeQ40wh2PpbFPmNjYf1SlGCsnIYkpXyCmcayR3U-pPHqpE6DLVBYo0M7FPJpRYIRF-BI2ac8RaXkAsBkjV_KFbNIgOuotCxXx1oWUwZl1ke3rZ-YbWEWud2sNM_rpbhgkPexJA72Kjx1qY6B7GulkGtFS8xXZiijxVT8ndT_j6U1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=Hq9M6Qgt67arOhYgXamfXnrRwrk7Qb16loyS7qQ_N1d4r2BRWAjZy8LzqPXhaoZOsXSb3b3NjeVrP6gCE7ZecEXkHpwM_4LWXOmtmxnckJ47-NMDMnQyaXuxDOzpV-ixfhcMzfO7pvgxOQFPFN52dw2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=h0MoYTYh4buT0KKNHnoPYkfyAMSq8gcVvQq7dC0Lx94wVhJQ-2WPsxPNQ2lQkcCdob-5hx9YChSOuCs7Sle_SqtYHBfVMaZS5woBp1hxO4ujK59IBXAQXbR8Kd1xC6Pe-CXRB3niMmpsc1K3XpKAKqTI_GMz0sfyxCwPPbe627Y1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=aWTqx5FIM9OO2thBpS0j6yLosCHLQYi7sDPobmsDQjuiq0n-WzNYFCkPwVhaCOdVqx747U15JJY1m_Bpn8BM5mH4ONkvAI56Eyrj9gxaBS3c-zYOAJx7sIETuC1S0RspQxUAyemsoKSaRbvyLARcmg2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=i-l8hmT7lmoBOtQD7ZomsYo6Zmp2B1j1r0eDctpX8Idkjr6bSZ8rufRZlz1jGSTm0dqVIkyoAvmhiJ8qkx_73_YCJIPTC1pmMJHIsWeE1_2MFlcMDpRHEwhcr0KiHIjsEg3tr9tIq4c8PgTTHqGxPverc-6Bw8o9IbiAx--TMGA1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=XcJwwBZ9MhksNijTVAWIxc3Maq9qm5XYYB-gOok_egw1lWldQZZjlupTme8MIAyq-2LgNar_Jxv0D0iVbvGvMq9n4vC3TdlpSnN5X_IHWYSM0wfZQsBNx1PmHSafApQZ-CFO-CodK3cNqtLNafgSxA2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=9CxiuPwlFUbpFfTnd1C4tY1cRFK3QZkQ54wYzNLU3AHjkyYeOUhA7PlXjw1F4zSTpdElX7WI1lC83lCXqQ0V_hZ5UnhXyu0IF9CurpxB2FXqhkhlUGUlAGjai-EjO2H4YYNSYYawxxVZX2t6HAGMqOj1t6qoWKVuMiLWKgN3ta41&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /></head>
<body>
    <form method="post" action=".eventgallery.php" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="ContentPlaceHolder1_RadScriptManager1_TSM" id="ContentPlaceHolder1_RadScriptManager1_TSM" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTkyODg1ODMzMg8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWAgIDD2QWBgIBDxYCHgRUZXh0BaQYPHVsIGlkPSduYXYnPjxsaT48YSBocmVmPScvZGVmYXVsdC5hc3B4JyA+IEhvbWUgPC9hPiA8L2xpPjxsaT48YSBocmVmPScvIycgPiBBYm91dCBFQ1AgPC9hPiA8dWw+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yMScgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPk92ZXJ2aWV3IG9mIEVDUDwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjInIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5Ib25vdXJhYmxlIENFQzwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjMnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5Ib25vdXJhYmxlIE1lbWJlcnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2NvbnRhY3QucGRmJyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+T2ZmaWNlcnM8L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IEZvciBWb3RlcnMgPC9hPiA8dWw+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD00JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+SG93IHRvIFJlZ2lzdGVyPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yOScgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkNoZWNrIFlvdXIgUmVnaXN0cmF0aW9uPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yNScgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkZBUXM8L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IEVsZWN0aW9ucyA8L2E+IDx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwNTEnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5HZW5lcmFsIEVsZWN0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA0MycgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkxHIEVsZWN0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjcnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5FbGVjdGlvbiBMYXdzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yNicgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkRlbGltaXRhdGlvbjwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA0NycgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkVsZWN0b3JhbCBSb2xsczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzEwNCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPlBhcnR5IFBvc2l0aW9uPC9hPjwvbGk+PC91bD48L2xpPjxsaT48YSBocmVmPScvIycgPiBNZWRpYSBFQ1AgPC9hPiA8dWw+PGxpPjxhIGhyZWY9Jy9QcmVzc1JlbGVhc2VzLmFzcHgnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5QcmVzcyBSZWxlYXNlczwvYT48L2xpPjxsaT48YSBocmVmPScvTmV3c2xldHRlcnMuYXNweCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPk5ld3NsZXR0ZXJzL1B1YmxpY2F0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvTm90aWZpY2F0aW9ucy5hc3B4JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+Tm90aWZpY2F0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtRXZlbnRzR2FsbGVyeS5hc3B4JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+SW1hZ2UgR2FsbGVyeTwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtdmlkZW9nYWxsZXJ5LmFzcHgnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5WaWRlbyBHYWxsZXJ5PC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMTU3JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+VHJhaW5pbmcgTWF0ZXJpYWw8L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IFBhcnRpZXMgJiBDYW5kaWRhdGVzIDwvYT4gPHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA4OScgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkxpc3Qgb2YgUG9saXRpY2FsIFBhcnRpZXM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwOTAnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5MaXN0IG9mIGFsbCBzeW1ib2xzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDkwJyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+QXZhaWxhYmxlIFN5bWJvbHM8L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yNCcgPiBEb3dubG9hZHMgPC9hPiA8L2xpPjxsaT48YSBocmVmPScvIycgPiBNaXNjLiA8L2E+IDx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI4JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+VGVuZGVyczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzE0OCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkNvbnRhY3QgVXM8L2E+PC9saT48bGk+PGEgaHJlZj0naHR0cHM6Ly93d3cuZWNwLmdvdi5way9jb250YWN0LnBkZicgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkVDUCBTZWNyZXRhcmlhdCBPZmZpY2VycyBDb250YWN0IE51bWJlcnM8L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDI0JyA+IEpvYnMgPC9hPiA8L2xpPjwvdWw+ZAIDD2QWBAIDDw8WCB4VRW5hYmxlRW1iZWRkZWRTY3JpcHRzZx4cRW5hYmxlRW1iZWRkZWRCYXNlU3R5bGVzaGVldGceElJlc29sdmVkUmVuZGVyTW9kZQspclRlbGVyaWsuV2ViLlVJLlJlbmRlck1vZGUsIFRlbGVyaWsuV2ViLlVJLCBWZXJzaW9uPTIwMTUuMS4yMjUuNDUsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MTIxZmFlNzgxNjViYTNkNAEeF0VuYWJsZUFqYXhTa2luUmVuZGVyaW5naBYCHgVzdHlsZQUNZGlzcGxheTpub25lO2QCBQ9kFgICAQ8UKwAGDxYOHwJnHwVoHwNnHgtfIURhdGFCb3VuZGceC18hSXRlbUNvdW50AgofBAsrBAEeEkFsbG93Q3VzdG9tU29ydGluZ2dkFCsAA2RkFCsAAhYCHhFJdGVtUGxhY2VIb2xkZXJJRAU5Y3RsMDBfQ29udGVudFBsYWNlSG9sZGVyMV9SYWRMaXN0VmlldzFfQ3VzdG9tZXJzQ29udGFpbmVyZBQrAAMPBQZfIURTSUMCEA8FC18hSXRlbUNvdW50AgoPBQhfIVBDb3VudAICFCsAChQrAAIUKwABBQdFdmVudElEFCsAAQIdFCsAAhQrAAEFB0V2ZW50SUQUKwABAiMUKwACFCsAAQUHRXZlbnRJRBQrAAECHBQrAAIUKwABBQdFdmVudElEFCsAAQIfFCsAAhQrAAEFB0V2ZW50SUQUKwABAiAUKwACFCsAAQUHRXZlbnRJRBQrAAECIRQrAAIUKwABBQdFdmVudElEFCsAAQISFCsAAhQrAAEFB0V2ZW50SUQUKwABAhMUKwACFCsAAQUHRXZlbnRJRBQrAAECFBQrAAIUKwABBQdFdmVudElEFCsAAQIVFgIeAl9jZmQWAmYPZBYYAgEPFCsAAg8WCB8ECysEAR8CZx8DZx8FaGQPAgQ8KwAEABYCAgMPZBYCAgEPFCsAAhQrAAgPFgweDUxhYmVsQ3NzQ2xhc3MFB3JpTGFiZWwfBWgfA2ceBFNraW4FB0RlZmF1bHQfBAsrBAEfAmdkFggeBVdpZHRoGwAAAAAAADlAAQAAAB4KUmVzaXplTW9kZQspclRlbGVyaWsuV2ViLlVJLlJlc2l6ZU1vZGUsIFRlbGVyaWsuV2ViLlVJLCBWZXJzaW9uPTIwMTUuMS4yMjUuNDUsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MTIxZmFlNzgxNjViYTNkNAAeCENzc0NsYXNzBRFyaVRleHRCb3ggcmlIb3Zlch4EXyFTQgKCAhYIHw4bAAAAAAAAOUABAAAAHw8LKwUAHxAFEXJpVGV4dEJveCByaUVycm9yHxECggIWCB8OGwAAAAAAADlAAQAAAB8PCysFAB8QBRNyaVRleHRCb3ggcmlGb2N1c2VkHxECggIWBh8OGwAAAAAAADlAAQAAAB8QBRNyaVRleHRCb3ggcmlFbmFibGVkHxECggIWCB8OGwAAAAAAADlAAQAAAB8PCysFAB8QBRRyaVRleHRCb3ggcmlEaXNhYmxlZB8RAoICFggfDhsAAAAAAAA5QAEAAAAfDwsrBQAfEAURcmlUZXh0Qm94IHJpRW1wdHkfEQKCAhYIHw4bAAAAAAAAOUABAAAAHw8LKwUAHxAFEHJpVGV4dEJveCByaVJlYWQfEQKCAhYIHw4bAAAAAAAAOUABAAAAHw8LKwUAHxAFFHJpVGV4dEJveCByaU5lZ2F0aXZlHxECggJkAgIPFQEHRGVmYXVsdGQCAw8WAh4OU2F2ZWRPbGRWYWx1ZXMXABYEZg8VBgIyORhOYXRpb25hbCBWb3RlcnMgRGF5IDIwMTcPUHJlc2lkZW50IEhvdXNlCjA3LzEyLzIwMTcCMjkCMjlkAgEPDxYIHw4bAAAAAAAAWUABAAAAHgZIZWlnaHQbAAAAAADAUkABAAAAHghJbWFnZVVybAVQfi9UZWxlcmlrLldlYi5VSS5XZWJSZXNvdXJjZS5heGQ/aW1naWQ9Yzg0OGE3NmUxZWVhNGI3NWJlMDU5NWIxODI5ODEzMWUmdHlwZT1yYmkfEQKAA2RkAgQPFgIfEhcAFgRmDxUGAjM1GU5hdGlvbmFsIFZvdGVycyBEYXkgMjAxOCAZUHJlc2lkZW50IEhvdXNlIElzbGFtYWJhZAowNy8xMi8yMDE4AjM1AjM1ZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAgElAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD01Njk3NWZiMDM2NTM0YTgzOTBlMmRjNjJmZDIxNzNiMCZ0eXBlPXJiaR8RAoADZGQCBQ8WAh8SFwAWBGYPFQYCMjgsSW5hdWdyYXRpb24gb2YgbmV3IFZvdGVyIFJlZ2lzdHJhdGlvbiBzeXN0ZW0FTkFEUkEKMTAvMTEvMjAxNwIyOAIyOGQCAQ8PFggfDhsAAAAAAABZQAEAAAAfExsAAAAAAIBQQAEAAAAfFAVQfi9UZWxlcmlrLldlYi5VSS5XZWJSZXNvdXJjZS5heGQ/aW1naWQ9YWIwNzY1M2I3NDRhNGQ0Y2I1NmMwZTFlODNlYThhZTkmdHlwZT1yYmkfEQKAA2RkAgYPFgIfEhcAFgRmDxUGAjMxHE5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNyBLUEsDS1BLCjA3LzEyLzIwMTcCMzECMzFkAgEPDxYIHw4bAAAAAAAAWUABAAAAHxMbAAAAAADAUkABAAAAHxQFUH4vVGVsZXJpay5XZWIuVUkuV2ViUmVzb3VyY2UuYXhkP2ltZ2lkPTk5NzZlZjA1ZjA0ODQ4NzRiOTI1MTQyMmUxOTgxNjYzJnR5cGU9cmJpHxECgANkZAIHDxYCHxIXABYEZg8VBgIzMh5OYXRpb25hbCBWb3RlcnMgRGF5IDIwMTcgU2luZGgACjA3LzEyLzIwMTcCMzICMzJkAgEPDxYIHw4bAAAAAAAAWUABAAAAHxMbAAAAAACAUEABAAAAHxQFUH4vVGVsZXJpay5XZWIuVUkuV2ViUmVzb3VyY2UuYXhkP2ltZ2lkPTI5YjM1MjUwOTJlMDRkNDg4Yzc4MGUxMThlYjA0MTllJnR5cGU9cmJpHxECgANkZAIIDxYCHxIXABYEZg8VBgIzMx9OYXRpb25hbCBWb3RlcnMgRGF5IDIwMTcgUHVuamFiAAowNy8xMi8yMDE3AjMzAjMzZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAgFBAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD1kZDNlMDVjYmRhZDk0MDZlYjEwOWZhMzZhMTVkNDYyNCZ0eXBlPXJiaR8RAoADZGQCCQ8WAh8SFwAWBGYPFQYCMTgYVm90ZXJzIERheSBDZWxlYnJhdGlvbnMgCUlzbGFtYWJhZAowNy8xMi8yMDE2AjE4AjE4ZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAAFlAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD1lN2FkYjQwOTQ2ZTU0NTQxOTcxOTY5ZmFlZDE4ZGYyMSZ0eXBlPXJiaR8RAoADZGQCCg8WAh8SFwAWBGYPFQYCMTkbVm90ZXJzIERheSBDZWxlYnJhdGlvbnMgS1BLA0tQSwowNy8xMi8yMDE2AjE5AjE5ZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAwFJAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD04YTY3NzdmN2Q1NGQ0NGFhOTIyMDQ1ODJjZDZlNDJlYSZ0eXBlPXJiaR8RAoADZGQCCw8WAh8SFwAWBGYPFQYCMjAeVm90ZXJzIERheSBDZWxlYnJhdGlvbnMgUHVuamFiBlB1bmphYgowNy8xMi8yMDE2AjIwAjIwZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAgFBAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD1jODdjMjE4ZjQ3YTU0ZDU5ODYwYTlhMzJiMGI4ZDE1YiZ0eXBlPXJiaR8RAoADZGQCDA8WAh8SFwAWBGYPFQYCMjEkVHJhaW5pbmcgb24gUk1TICYgR0lTIFBvbGxpbmcgU2NoZW1lCUlzbGFtYWJhZAoyNC8xMS8yMDE2AjIxAjIxZAIBDw8WCB8OGwAAAAAAAFlAAQAAAB8TGwAAAAAAgFBAAQAAAB8UBVB+L1RlbGVyaWsuV2ViLlVJLldlYlJlc291cmNlLmF4ZD9pbWdpZD1jMjM4MjIzMjkzN2U0ZDEyYjNhNGU1MjdiYzQ3OTk3MiZ0eXBlPXJiaR8RAoADZGQCBA8WAh8BBbYOPGRpdiBjbGFzcz0nc3BhbjInPjxkaXYgY2xhc3M9J2JveC0xJz48aDQ+QWJvdXQgRUNQPC9oND48dWw+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yMSc+T3ZlcnZpZXcgb2YgRUNQPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yMic+SG9ub3VyYWJsZSBDRUM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTIzJz5Ib25vdXJhYmxlIE1lbWJlcnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2NvbnRhY3QucGRmJz5PZmZpY2VyczwvYT48L2xpPjwvdWw+PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz0nc3BhbjInPjxkaXYgY2xhc3M9J2JveC0xJz48aDQ+Rm9yIFZvdGVyczwvaDQ+PHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9NCc+SG93IHRvIFJlZ2lzdGVyPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yOSc+Q2hlY2sgWW91ciBSZWdpc3RyYXRpb248L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI1Jz5GQVFzPC9hPjwvbGk+PC91bD48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzPSdzcGFuMic+PGRpdiBjbGFzcz0nYm94LTEnPjxoND5FbGVjdGlvbnM8L2g0Pjx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwNTEnPkdlbmVyYWwgRWxlY3Rpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDQzJz5MRyBFbGVjdGlvbnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI3Jz5FbGVjdGlvbiBMYXdzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yNic+RGVsaW1pdGF0aW9uPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDQ3Jz5FbGVjdG9yYWwgUm9sbHM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMxMDQnPlBhcnR5IFBvc2l0aW9uPC9hPjwvbGk+PC91bD48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzPSdzcGFuMic+PGRpdiBjbGFzcz0nYm94LTEnPjxoND5NZWRpYSBFQ1A8L2g0Pjx1bD48bGk+PGEgaHJlZj0nL1ByZXNzUmVsZWFzZXMuYXNweCc+UHJlc3MgUmVsZWFzZXM8L2E+PC9saT48bGk+PGEgaHJlZj0nL05ld3NsZXR0ZXJzLmFzcHgnPk5ld3NsZXR0ZXJzL1B1YmxpY2F0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvTm90aWZpY2F0aW9ucy5hc3B4Jz5Ob3RpZmljYXRpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1FdmVudHNHYWxsZXJ5LmFzcHgnPkltYWdlIEdhbGxlcnk8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybXZpZGVvZ2FsbGVyeS5hc3B4Jz5WaWRlbyBHYWxsZXJ5PC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMTU3Jz5UcmFpbmluZyBNYXRlcmlhbDwvYT48L2xpPjwvdWw+PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz0nc3BhbjInPjxkaXYgY2xhc3M9J2JveC0xJz48aDQ+TWlzYy48L2g0Pjx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI4Jz5UZW5kZXJzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMTQ4Jz5Db250YWN0IFVzPC9hPjwvbGk+PGxpPjxhIGhyZWY9J2h0dHBzOi8vd3d3LmVjcC5nb3YucGsvY29udGFjdC5wZGYnPkVDUCBTZWNyZXRhcmlhdCBPZmZpY2VycyBDb250YWN0IE51bWJlcnM8L2E+PC9saT48L3VsPjwvZGl2PjwvZGl2PmQYAgUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgMFK2N0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkUmFkRm9ybURlY29yYXRvcjEFJmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkUmFkTGlzdFZpZXcxBTRjdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJFJhZExpc3RWaWV3MSRSYWREYXRhUGFnZXIxBTRjdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJFJhZExpc3RWaWV3MSRSYWREYXRhUGFnZXIxDxQrAARkZgIKAhBkJsHHZE9ACihL0kR2BCiLC/CqnOd3yCpeqPr/YjtCu+U=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=9Q3Tw_ROuEL9S04FtdLl2H6opHHLhfOMojp_etOpjpORq31YnZDSqa5xlUjEAbNdtZzacgftYH6U1qJNiOd5L4yxZkJc2kdDRjjirvgm6sk1&amp;t=636042899952281841" type="text/javascript"></script>


<script src="/Telerik.Web.UI.WebResource.axd?_TSM_HiddenField_=ContentPlaceHolder1_RadScriptManager1_TSM&amp;compress=1&amp;_TSM_CombinedScripts_=%3b%3bSystem.Web.Extensions%2c+Version%3d4.0.0.0%2c+Culture%3dneutral%2c+PublicKeyToken%3d31bf3856ad364e35%3aen-US%3af9ecfe64-7d94-4875-a470-9996e4d00a9f%3aea597d4b%3ab25378d2%3bTelerik.Web.UI%2c+Version%3d2015.1.225.45%2c+Culture%3dneutral%2c+PublicKeyToken%3d121fae78165ba3d4%3aen-US%3ad3cd47d0-4d93-4bad-8b9f-f9fea0aa4c69%3a16e4e7cd%3a4877f69a%3a86526ba7%3a874f8ea2%3af7645509%3addbfcb67%3a4a0008d8%3ab7778d6c%3ae085fe68" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="D8AE7D63" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAmjQe0Aqbc+5sg729iTFkIM+HGgwqGlmg/JsnCi2c9MNYXwjg1T9EK9aTpmKwcAhmXPdq0hLhRcEhc2hlBo31DKnjPzKlfS8EOBbV3670IknuSFAYu4wd74o/sq+71Aks6t8O/4tlfsBo0/EvHGGfW84AVwDDVYar9Vea3iVKajiEi7TkJJSQQ3XxoH0arlhtt4ICSK+VDHCpL9C2n5k4U6m8nNjWJ7dDxZwYgHBEtz7w==" />
</div>
        <div>

            <!--Wrapper Start-->
            <div id="wrapper">
                <!--Headre Start-->
                <header id="header">
                    <!--Head Topbar Start-->
                    <div class="head-topbar-Green">
                        <div class="container">
                            <div class="row-fluid">
                                <div id="ECPHeading" class="left">
                                <ul class="header-social">
                                            <li><img src=' ./images/1.png' /></li>           
                                </ul>
                                </div>
                                
                            </div>
                        </div>
                    </div> 

               
           
            <!--Head Topbar End-->
            <!--Menu Row Start-->
            <div class="menu-row">
                <div class="container">
                    <div class="row-fluid">
                        <strong class="logo"><a href="default.php">
                            <img src=' ./images/logo.png' alt="img"></a></strong>
                    </div>
                </div>
                <!--Navigation Area	Start-->
               
                <section class="navigation-area">
 <div id="list1">
                    <div class="container">
                        <div class="row-fluid">
                            <!--Navbar Start-->
                            <div class="navbar margin-none">
                                <div class="container">
                                    <button data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar" type="button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                                    <div class="nav-collapse collapse">
                                        <div id="navbar">
                                            <ul id='nav'><li><a href='default.php' > Home </a> </li><li><a href='/#' > About ECP </a> <ul><li><a href='Overview.php' class='dir' style='cursor: pointer;'>Overview of ECP</a></li><li><a href='HonourableCEC.php' class='dir' style='cursor: pointer;'>Honourable CEC</a></li><li><a href='HonourableMember.php' class='dir' style='cursor: pointer;'>Honourable Members</a></li><li><a href='contact.pdf' class='dir' style='cursor: pointer;'>Officers</a></li></ul></li><li><a href='login.php' class='dir' style='cursor: pointer;'>For Officers</a></li><li><a href='/#' > For Voters </a> <ul><li><a href='HowtoRegister.php' class='dir' style='cursor: pointer;'>How to Register</a></li><li><a href='CheckRegistration.php' class='dir' style='cursor: pointer;'>Check Your Registration</a></li><li><a href='FAQs.php' class='dir' style='cursor: pointer;'>FAQs</a></li></ul></li><li><a href='/#' > Elections </a> <ul><li><a href='generalelection.php' class='dir' style='cursor: pointer;'>General Elections</a></li><li><a href='lgelection.php' class='dir' style='cursor: pointer;'>LG Elections</a></li><li><a href='electionlaws.php' class='dir' style='cursor: pointer;'>Election Laws</a></li><li><a href='delimitation.php' class='dir' style='cursor: pointer;'>Delimitation</a></li><li><a href='electoralrolls.php' class='dir' style='cursor: pointer;'>Electoral Rolls</a></li><li><a href='partyposition.php' class='dir' style='cursor: pointer;'>Party Position</a></li></ul></li><li><a href='/#' > Media ECP </a> <ul><li><a href='PressRelease.php' class='dir' style='cursor: pointer;'>Press Releases</a></li><li><a href='Newsletters.php' class='dir' style='cursor: pointer;'>Newsletters/Publications</a></li><li><a href='Notifications.php' class='dir' style='cursor: pointer;'>Notifications</a></li><li><a href='imagegallery.php' class='dir' style='cursor: pointer;'>Image Gallery</a></li><li><a href='videogallery.php' class='dir' style='cursor: pointer;'>Video Gallery</a></li><li><a href='trainingmaterial.php' class='dir' style='cursor: pointer;'>Training Material</a></li></ul></li><li><a href='/#' > Parties & Candidates </a> <ul><li><a href='listofpoliticalparties.php' class='dir' style='cursor: pointer;'>List of Political Parties</a></li><li><a href='listofallsymbols.php' class='dir' style='cursor: pointer;'>List of all symbols</a></li><li><a href='availablesymbols.php' class='dir' style='cursor: pointer;'>Available Symbols</a></li></ul></li><li><a href='download.php' > Downloads </a> </li><li><a href='/#' > Misc. </a> <ul><li><a href='tenders.php' class='dir' style='cursor: pointer;'>Tenders</a></li><li><a href='contactus.php' class='dir' style='cursor: pointer;'>Contact Us</a></li><li><a href='contact.pdf' class='dir' style='cursor: pointer;'>ECP Secretariat Officers Contact Numbers</a></li></ul></li><li><a href='job.php' > Jobs </a> </li></ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <!--Navbar End-->
                        </div>
                    </div>
</div>
                </section>
                    
                <!--Navigation Area	End-->
            </div>
            <!--Menu Row End-->
            </header>
  <!--Headre End-->
            <div id="main">
                <!--Banner Start-->
                <div id="banner">
                    <div id="inner-banner">
                        <div class="container">
                            
    <h1>Image Gallery</h1>
    <p></p>

                        </div>
                    </div>
                </div>
                <!--Banner End-->

                <!--Blog Page Start-->

                <section class="blog-page">
                    <div class="container">

                        <div class="row-fluid">
                            <div class="span9">
                                <div class="blog-content">
                                    <!--Photo Post Start-->
                                    
    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ContentPlaceHolder1$RadScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>

    <div id="ctl00_ContentPlaceHolder1_RadFormDecorator1" class="RadFormDecorator" style="display:none;">
	<!-- 2015.1.225.45 --><script type="text/javascript">
//<![CDATA[
if (typeof(WebForm_AutoFocus) != 'undefined')
{
	var old_WebForm_AutoFocus = WebForm_AutoFocus;
	WebForm_AutoFocus = function(arg)
	{
		Sys.Application.add_load(function()
		{
			old_WebForm_AutoFocus(arg);
			WebForm_AutoFocus = old_WebForm_AutoFocus;
		});
	}
}
if (typeof(Telerik) != 'undefined' && Type.isNamespace(Telerik.Web))
{
	if (Telerik.Web.UI.RadFormDecorator)
	{
		Telerik.Web.UI.RadFormDecorator.initializePage("ctl00_ContentPlaceHolder1_RadFormDecorator1", "demo-container", "Default", 65535);
	}
}
//]]>
</script><input id="ctl00_ContentPlaceHolder1_RadFormDecorator1_ClientState" name="ctl00_ContentPlaceHolder1_RadFormDecorator1_ClientState" type="hidden" />
</div>
    <div id="demo-container">        
       
        <table>
            <tr>
                <td>
                    
                    <div id="ContentPlaceHolder1_ListViewPanel1">
	
                        
                                <!-- Set the id of the wrapping container to match the CLIENT ID of the RadListView control to display the ajax loading panel
                         In case the listview is embedded in another server control, you will need to append the id of that server control -->
                                <fieldset id="FiledSet1" class="mainFieldset">
                                    <legend><h3> Events / Seminars</h3></legend>
                                    <table cellpadding="0" cellspacing="0" width="100%">
                                        <tr>
                                            <td>
                                                <div id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1" class="RadDataPager RadDataPager_Default pagerStyle">
		<div class="rdpWrap">
			<input type="submit" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl00$FirstButton" value=" " onclick="return false;" id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl00_FirstButton" class="rdpPageFirst" /><input type="submit" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl00$PrevButton" value=" " onclick="return false;" id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl00_PrevButton" class="rdpPagePrev" />
		</div><div class="rdpWrap rdpNumPart">
			<a onclick="return false;" class="rdpCurrentPage" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl01$ctl00&#39;,&#39;&#39;)"><span>1</span></a><a href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl01$ctl01&#39;,&#39;&#39;)"><span>2</span></a>
		</div><div class="rdpWrap">
			<input type="submit" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl02$NextButton" value=" " id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl02_NextButton" class="rdpPageNext" /><input type="submit" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl02$LastButton" value=" " id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl02_LastButton" class="rdpPageLast" />
		</div><div class="rdpWrap">
			<span class='rdpPagerLabel'>Page: </span><span id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox_wrapper" class="riSingle RadInput RadInput_Default" style="width:25px;"><input id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl03$GoToPageTextBox" class="riTextBox riEnabled" value="1" type="text" /><input id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox_ClientState" name="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox_ClientState" type="hidden" /></span><span class='rdpPagerLabel'>of 2</span><input type="submit" name="ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl03$GoToPageButton" value="Go" id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageButton" class="rdpPagerButton" />
		</div><input id="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ClientState" name="ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ClientState" type="hidden" />
	</div>
                                            </td>
                                        </tr>
                                    </table>
                                    <div class="RadListView RadListView_Default">
                                        
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=29"> <font color="#000000" size="2"> National Voters Day 2017</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> President House</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2017</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=29"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=29">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl0_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=c848a76e1eea4b75be0595b18298131e&amp;type=rbi" alt="Contact Photo" style="height:75px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=35"> <font color="#000000" size="2"> National Voters Day 2018 </font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> President House Islamabad</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2018</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=35"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=35">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl1_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=56975fb036534a8390e2dc62fd2173b0&amp;type=rbi" alt="Contact Photo" style="height:51px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=28"> <font color="#000000" size="2"> Inaugration of new Voter Registration system</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> NADRA</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  10/11/2017</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=28"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=28">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl2_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=ab07653b744a4d4cb56c0e1e83ea8ae9&amp;type=rbi" alt="Contact Photo" style="height:66px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=31"> <font color="#000000" size="2"> National Voters Day 2017 KPK</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> KPK</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2017</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=31"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=31">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl3_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=9976ef05f0484874b9251422e1981663&amp;type=rbi" alt="Contact Photo" style="height:75px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=32"> <font color="#000000" size="2"> National Voters Day 2017 Sindh</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> </font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2017</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=32"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=32">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl4_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=29b3525092e04d488c780e118eb0419e&amp;type=rbi" alt="Contact Photo" style="height:66px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=33"> <font color="#000000" size="2"> National Voters Day 2017 Punjab</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> </font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2017</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=33"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=33">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl5_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=dd3e05cbdad9406eb109fa36a15d4624&amp;type=rbi" alt="Contact Photo" style="height:66px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=18"> <font color="#000000" size="2"> Voters Day Celebrations </font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> Islamabad</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2016</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=18"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=18">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl6_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=e7adb40946e54541971969faed18df21&amp;type=rbi" alt="Contact Photo" style="height:100px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=19"> <font color="#000000" size="2"> Voters Day Celebrations KPK</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> KPK</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2016</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=19"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=19">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl7_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=8a6777f7d54d44aa92204582cd6e42ea&amp;type=rbi" alt="Contact Photo" style="height:75px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=20"> <font color="#000000" size="2"> Voters Day Celebrations Punjab</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> Punjab</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  07/12/2016</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=20"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=20">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl8_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=c87c218f47a54d59860a9a32b0b8d15b&amp;type=rbi" alt="Contact Photo" style="height:66px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                <!--The widths/heights of the fieldset/outer tables in the item/edit/insert templates should match to avoid wrapping or visual discrepancies
                             in the tiles layout-->
                                <fieldset class="fieldset">
                                    <legend><b>
                                       <a href="frmImageGallery.aspx?EventId=21"> <font color="#000000" size="2"> Training on RMS & GIS Polling Scheme</font></a></b></legend>
                                    <table class="dataTable">
                                        <tr class="rlvI">
                                            <td>
                                                <table class="itemTable">
                                                    <tr>
                                                        <td>
                                                            <table class="innerItemTable">
                                                                
                                                                <tr>
                                                                    <td><b><font size="2pt"> Location</font></b>:
                                                                    </td>
                                                                    <td>
                                                                        <font size="2pt"> Islamabad</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> Date:</font></b>
                                                                    </td>
                                                                    <td>
                                                                       <font size="2pt">  24/11/2016</font>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><font size="2pt"> </font></b>
                                                                    </td>
                                                                    <td>
                                                                       <a href="frmImageGallery.aspx?EventId=21"> <font size="2pt" color="#000000"> <u><i>View Gallery</i></u></font></a><br /><br /><br />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="image"><a href="frmImageGallery.aspx?EventId=21">
                                                            <img id="ctl00_ContentPlaceHolder1_RadListView1_ctrl9_RadBinaryImage1" title="Contact Photo" src="Telerik.Web.UI.WebResource.axd?imgid=c2382232937e4d12b3a4e527bc479972&amp;type=rbi" alt="Contact Photo" style="height:66px;width:100px;" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            
                                    </div>
                                    <div class="clearFix">
                                    </div>
                                </fieldset>
                            <input id="ctl00_ContentPlaceHolder1_RadListView1_ClientState" name="ctl00_ContentPlaceHolder1_RadListView1_ClientState" type="hidden" /><span id="ctl00_ContentPlaceHolder1_RadListView1" style="display:none;"></span>
                    
</div>
                </td>
            </tr>
        </table>
        <br />
        
        
    </div>  


                                    <!--Photo Post End-->
                                </div>
                            </div>
                            <div class="span3">
                                <!--Sidebar Start-->
                                <aside>
                                    <div id="sidebar">
                                        <form action="#" class="sidebar-form">
                                            
                                            
                                            <div class="sidebar-member"><a href="frmGenericPage.aspx?PageID=3036" class="member-icon2"><i class="fa fa-user"></i></a><a href="frmGenericPage.aspx?PageID=3036" class="member-text2">Check your vote</a> </div>
                                        </form>
                                        <!--Sidebar Upcoming News Box Start-->
                                        <div class="sidebar-recent-post">
                                           
                                            
                                        </div>
                                        <!--Sidebar Upcoming News Box End-->
                                        <!--Sidebar Related Links Box Start-->
                                        <div class="sidebar-recent-post">
                                            <h3>Related Links</h3>
                                            <div class="list-area">
                                                <ul>
                                                    <li><a href="electionlaws.php"><span></span>Election Laws</a></li>
                                                    <li><a href="listofpoliticalparties.php"><span></span>List of Political Parties</a></li>
                                                   
                                                    <li><a href="availablesymbols.php"><span></span>Symbols Allotted to Political Parties</a></li>
                                                    <li><a href="FAQs.php"><span></span>FAQs</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!--Sidebar Related Links Box End-->
                                    </div>
                                </aside>
                                <!--Sidebar End-->
                            </div>
                        </div>
                    </div>
                </section>
                <!--Blog Page End-->

                <!--Footer Start-->
                <section id="footer">
                    <!--Footer Top Start-->
                    <div class="footer-top">
                        <div class="container">
                            <div class="row-fluid">
                                <div class="span2">
                                    <div class="box-1 box-first">

                                        <div>
                                            <strong class="footer-logo"><a href="#">ECP</a></strong>

                                        </div>

                                    </div>
                                </div>
                                <div class='span2'><div class='box-1'><h4>About ECP</h4><ul><li><a href='Overview.php'>Overview of ECP</a></li><li><a href='HonourableCEC.php'>Honourable CEC</a></li><li><a href='HonourableMember.php'>Honourable Members</a></li><li><a href='contact.pdf'>Officers</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>For Voters</h4><ul><li><a href='HowtoRegister.php'>How to Register</a></li><li><a href='CheckRegistration.php'>Check Your Registration</a></li><li><a href='FAQs.php'>FAQs</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Elections</h4><ul><li><a href='generalelection.php'>General Elections</a></li><li><a href='lgelection.php'>LG Elections</a></li><li><a href='electionlaws.php'>Election Laws</a></li><li><a href='delimitation.php'>Delimitation</a></li><li><a href='electoralrolls.php'>Electoral Rolls</a></li><li><a href='partyposition.php'>Party Position</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Media ECP</h4><ul><li><a href='PressReleases.php'>Press Releases</a></li><li><a href='Newsletters.php'>Newsletters/Publications</a></li><li><a href='Notifications.php'>Notifications</a></li><li><a href='eventgallery.php'>Image Gallery</a></li><li><a href='videogallery.php'>Video Gallery</a></li><li><a href='trainingmaterial.php'>Training Material</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Misc.</h4><ul><li><a href='tenders.php'>Tenders</a></li><li><a href='contactus.php'>Contact Us</a></li><li><a href='contact.pdf'>ECP Secretariat Officers Contact Numbers</a></li></ul></div></div>
                            </div>
                        </div>
                    </div>
                    <!--Footer Top End-->
                    <!--Footer Copyright Start-->
                    <div class="footer-copyright"><strong class="copy">Copyright &copy; ECP 2018 - Election Commission of Pakistan.</strong></div>
                    <!--Footer Copyright End-->
                </section>
                <!--Footer End-->
            </div>

        </div>
        <!--Wrapper End-->
        <!--Jquery Js-->
        <script src="adminw/js/jquery.js" type="text/javascript"></script>
        <!--Bootstrap Js-->
        <script src="adminw/js/bootstrap.js" type="text/javascript"></script>
        <!--Upcoming News Times Js-->
        <script src="adminw/js/jquery.plugin.js"></script>
        <!--Upcoming News Times Js-->
        <script src="adminw/js/jquery.countdown.js"></script>
        <!--Bxslider Js-->
        <script src="adminw/js/jquery.bxslider.min.js"></script>
        <!--Filterable JS-->
        <script type="text/javascript" src="adminw/js/jquery-filterable.js"></script>
        <!--Flex Timeline JS-->
        <script type="text/javascript" src="adminw/js/jquery.flexisel.js"></script>
        <!--Pretty Photo Js-->
        <script src="adminw/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
        <!-- Style Switcher -->
        <script type="text/javascript" src="adminw/js/styleswitch.js"></script>
        <script type="text/javascript" src="adminw/js/jquery.tabSlideOut.v1.3.js"></script>
        <!--Costom Js-->
        <script src="adminw/js/custom.js" type="text/javascript"></script>
<div class="addthis_sharing_toolbox"> </div>
            <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-55f3af0d2d622184" async="async"></script>
        </div>
    

<script type="text/javascript">
//<![CDATA[
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadFormDecorator, {"_renderMode":1,"clientStateFieldID":"ctl00_ContentPlaceHolder1_RadFormDecorator1_ClientState","decoratedControls":65535,"decorationZoneID":"demo-container","enableRoundedCorners":false,"enabled":true,"skin":"Default"}, null, null, $get("ctl00_ContentPlaceHolder1_RadFormDecorator1"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadNumericTextBox, {"_displayText":"1","_focused":false,"_initialValueAsText":"1","_postBackEventReferenceScript":"setTimeout(\"__doPostBack(\\\u0027ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1$ctl03$GoToPageTextBox\\\u0027,\\\u0027\\\u0027)\", 0)","_skin":"Default","_validationText":"1","clientStateFieldID":"ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox_ClientState","enabled":true,"incrementSettings":{InterceptArrowKeys:true,InterceptMouseWheel:true,Step:1},"maxValue":2,"minValue":1,"numberFormat":{"DecimalDigits":0,"DecimalSeparator":".","CultureNativeDecimalSeparator":".","GroupSeparator":",","GroupSizes":3,"NegativePattern":"-n","NegativeSign":"-","PositivePattern":"n","AllowRounding":false,"KeepNotRoundedValue":false,"KeepTrailingZerosOnFocus":false,"NumericPlaceHolder":"n"},"styles":{HoveredStyle: ["width:25px;", "riTextBox riHover"],InvalidStyle: ["width:25px;", "riTextBox riError"],DisabledStyle: ["width:25px;", "riTextBox riDisabled"],FocusedStyle: ["width:25px;", "riTextBox riFocused"],EmptyMessageStyle: ["width:25px;", "riTextBox riEmpty"],ReadOnlyStyle: ["width:25px;", "riTextBox riRead"],EnabledStyle: ["width:25px;", "riTextBox riEnabled"],NegativeStyle: ["width:25px;", "riTextBox riNegative"]}}, null, null, $get("ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ctl03_GoToPageTextBox"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadDataPager, {"_currentPageIndex":0,"_pageCount":2,"_pageSize":10,"_startRowIndex":0,"_totalRowCount":16,"_uniqueID":"ctl00$ContentPlaceHolder1$RadListView1$RadDataPager1","clientStateFieldID":"ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1_ClientState"}, null, null, $get("ctl00_ContentPlaceHolder1_RadListView1_RadDataPager1"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadListView, {"UniqueID":"ctl00$ContentPlaceHolder1$RadListView1","_allowPaging":true,"_clientSettings":{"DataBinding":{"ItemPlaceHolderID":"ctl00_ContentPlaceHolder1_RadListView1_CustomersContainer","DataService":{}}},"_virtualItemCount":16,"clientStateFieldID":"ctl00_ContentPlaceHolder1_RadListView1_ClientState","renderMode":1}, null, null, $get("ctl00_ContentPlaceHolder1_RadListView1"));
});
//]]>
</script>
</form>
</body>
</html>
