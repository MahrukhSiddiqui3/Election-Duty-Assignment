


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta charset="utf-8" /><title>
	ECP - Election Commission of Pakistan
</title><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--Custom Css-->
    <link href="adminw/css/custom.css" rel="stylesheet" type="text/css" />
    <!--Bootstrap Css-->
    <link href="adminw/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!--Bootstrap Responsive Css-->
    <link href="adminw/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
    <!--Color Css-->
    <link href="adminw/css/color.css" rel="stylesheet" type="text/css" />
    <!--Font Awesome Css-->
    <link href="adminw/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!--Fevicon-->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <!--Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Slab:300,400,700" rel="stylesheet" type="text/css" /><link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
    <!--Bxslider Css-->
    <link href="adminw/css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
    <!--Pretty Photo Css-->
    <link rel="stylesheet" href="adminw/css/prettyPhoto.css" type="text/css" media="screen" />
    <!--Html 5 Js-->
    <script src="adminw/js/html5.js" type="text/javascript"></script>
    <!-- Color Css Files Start -->
    <link rel="alternate stylesheet" type="text/css" href="adminw/css/color-red.css" title="styles1" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-red.css" title="styles1" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-skyblue.css" title="styles2" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-orange.css" title="styles3" media="screen" /><link rel="stylesheet" type="text/css" href="adminw/css/color-green.css" title="styles4" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-blue.css" title="styles5" media="screen" /><link rel="alternate stylesheet" type="text/css" href="adminw/css/color-brown.css" title="styles6" media="screen" />
    <!-- Color Css Files End -->
    <!-- Progress bar -->
      



    


    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
    <script type="text/javascript">// <![CDATA[
        $(function () {
            var listval = $('#list1')[0].offsetTop; $(document).scroll(function () {
                var topval = $(document).scrollTop(); if (topval >= listval) {
                    $('#list1').addClass('fixed');
                } else {
                    $('#list1').removeClass('fixed');
                }

            });

        });
        // ]]>
    </script>
    <style type="text/css">
#list1
{
	
	z-index: 1000;
}
.fixed{
position:fixed;
width: 100%;
top: 0px;
}
</style>
<link href="/WebResource.axd?d=TiQZQn6ndDqfIJm_t6U5q8ocI7eVPjpJ_5_zxv-sji2LQvZQkT7lq8ehFku4NWivqUVQMQ1Id5WZds-RLlaSkTuhoUYp4Hp0R3hgoISOXFCecwX4gnrezn7gL5i6DHOb5ArKwTTxI4JHPY7qBlbNag2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=aerEx93Frk8Rp_DhPl1AFqWULml6j7wmXeOMNItr5hNj2khOE2kzfnBBBUtKc-pKSMzyo4LbG8QE2PLkhIFQ72t506lG7DLoecntZm0rRdQBleWry9Tywk8tDcs5JtLGcOtE1a8DxrC4AQ4vQBpM-ND9YsSYGiVplV4Q9UatOT41&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=BRo7jcSHEfMllRT3Ei1b9uoC98ShPRO0RNzeuPjMe5OPlcm1uuvrRHr33-uFkVM9v4XpMRR6gtwoK6vMuCdJEZf4NEHR-yXMlRJeSOzVvQbrtU-I7VHpM02tz_61wIaDdoBogacNyXxlwy2mu1g_TQ2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=YgrUZHrNovPXD3C6Utz1Nvcbo6HwvPDXYqWYi4D_W_3DzTP8Hbw9Rf6vxfLdAX013is_C48lZPtJl5Bh32JJTdm_j2HVI3zTL-csRM2mtqB4BaiSzBnRIdj5lTH1wR7fDYfGetMSxe5UyD-s_aLOMMIIRM-hKREp8FTls8_e0Ws1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=keG-lhK1O0Mml7-qMXUf-2LOR265LwVj7ZvXebslFFaoq3nyOBMu10hRsDffaPN9VOuOvpu7Jn9LwAa0tQAilIqIu9BOvdEg3EibHpz5U_jrXZEsVoCfL3oZFMlmRiwZFtvYEnI3nPeMbg4f3PVJHQ2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=O9HicTKTE4rAae1p0Alq3Vtib4ecG1aer6AOxgKhw7OBfL1cVTDjmHaZJL-5oSnBpBQK85PY_sTT2KmwbQX8CQc88r36-hd4LzVaLqJq8FgpLimGGprAp49TYkNFWMD5vcQwgXfj4PRUfRumnwEeWcqL9oe_Q9M-_YMzuzBgOEc1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=Hq9M6Qgt67arOhYgXamfXnrRwrk7Qb16loyS7qQ_N1d4r2BRWAjZy8LzqPXhaoZOsXSb3b3NjeVrP6gCE7ZecEXkHpwM_4LWXOmtmxnckJ47-NMDMnQyaXuxDOzpV-ixfhcMzfO7pvgxOQFPFN52dw2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=h0MoYTYh4buT0KKNHnoPYkfyAMSq8gcVvQq7dC0Lx94wVhJQ-2WPsxPNQ2lQkcCdob-5hx9YChSOuCs7Sle_SqtYHBfVMaZS5woBp1hxO4ujK59IBXAQXbR8Kd1xC6Pe-CXRB3niMmpsc1K3XpKAKqTI_GMz0sfyxCwPPbe627Y1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=3XxgyY-boMFZu_pFY5DlYlNC9LisjFxH9G_ZZAnYsibhMFLE8_ESpUInIf5DbBH9UNWEb6PD5576Cy2vIQATBKyvtRqchnWo8c82hCIP57_vgok491PF290g_3U229AJVfAnwch0cTX2qFuM6g_Zpg2&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /><link href="/WebResource.axd?d=q0ECNZUffVHXfzmZoscAtE7On9NRyqZzNj_zwChq5XDkUpmjolWtJjvAtT8Kk8nVRxbC_ETCkSymTqSbdUzC9asTbUS-ipd1bhBWV__j_T6IcDSiQX9aZUAPdKr6QpgJxSE4bgOpD5bEulSlc7xWCb3KxhmRch1tphnFpqloFWA1&amp;t=635779927213250000" type="text/css" rel="stylesheet" class="Telerik_stylesheet" /></head>
<body>
    <form method="post" action="./frmvideogallery.aspx" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="ContentPlaceHolder1_RadScriptManager1_TSM" id="ContentPlaceHolder1_RadScriptManager1_TSM" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJMzU0Njg5OTg5DxYCHhNWYWxpZGF0ZVJlcXVlc3RNb2RlAgEWAmYPZBYCAgMPZBYGAgEPFgIeBFRleHQFpBg8dWwgaWQ9J25hdic+PGxpPjxhIGhyZWY9Jy9kZWZhdWx0LmFzcHgnID4gSG9tZSA8L2E+IDwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IEFib3V0IEVDUCA8L2E+IDx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTIxJyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+T3ZlcnZpZXcgb2YgRUNQPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yMicgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkhvbm91cmFibGUgQ0VDPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yMycgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkhvbm91cmFibGUgTWVtYmVyczwvYT48L2xpPjxsaT48YSBocmVmPScvY29udGFjdC5wZGYnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5PZmZpY2VyczwvYT48L2xpPjwvdWw+PC9saT48bGk+PGEgaHJlZj0nLyMnID4gRm9yIFZvdGVycyA8L2E+IDx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTQnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5Ib3cgdG8gUmVnaXN0ZXI8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI5JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+Q2hlY2sgWW91ciBSZWdpc3RyYXRpb248L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI1JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+RkFRczwvYT48L2xpPjwvdWw+PC9saT48bGk+PGEgaHJlZj0nLyMnID4gRWxlY3Rpb25zIDwvYT4gPHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA1MScgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkdlbmVyYWwgRWxlY3Rpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDQzJyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+TEcgRWxlY3Rpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0yNycgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkVsZWN0aW9uIExhd3M8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI2JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+RGVsaW1pdGF0aW9uPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDQ3JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+RWxlY3RvcmFsIFJvbGxzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMTA0JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+UGFydHkgUG9zaXRpb248L2E+PC9saT48L3VsPjwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IE1lZGlhIEVDUCA8L2E+IDx1bD48bGk+PGEgaHJlZj0nL1ByZXNzUmVsZWFzZXMuYXNweCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPlByZXNzIFJlbGVhc2VzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9OZXdzbGV0dGVycy5hc3B4JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+TmV3c2xldHRlcnMvUHVibGljYXRpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9Ob3RpZmljYXRpb25zLmFzcHgnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5Ob3RpZmljYXRpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1FdmVudHNHYWxsZXJ5LmFzcHgnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5JbWFnZSBHYWxsZXJ5PC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm12aWRlb2dhbGxlcnkuYXNweCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPlZpZGVvIEdhbGxlcnk8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMxNTcnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5UcmFpbmluZyBNYXRlcmlhbDwvYT48L2xpPjwvdWw+PC9saT48bGk+PGEgaHJlZj0nLyMnID4gUGFydGllcyAmIENhbmRpZGF0ZXMgPC9hPiA8dWw+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMDg5JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+TGlzdCBvZiBQb2xpdGljYWwgUGFydGllczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA5MCcgY2xhc3M9J2Rpcicgc3R5bGU9J2N1cnNvcjogcG9pbnRlcjsnPkxpc3Qgb2YgYWxsIHN5bWJvbHM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwOTAnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5BdmFpbGFibGUgU3ltYm9sczwvYT48L2xpPjwvdWw+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI0JyA+IERvd25sb2FkcyA8L2E+IDwvbGk+PGxpPjxhIGhyZWY9Jy8jJyA+IE1pc2MuIDwvYT4gPHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjgnIGNsYXNzPSdkaXInIHN0eWxlPSdjdXJzb3I6IHBvaW50ZXI7Jz5UZW5kZXJzPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD0zMTQ4JyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+Q29udGFjdCBVczwvYT48L2xpPjxsaT48YSBocmVmPSdodHRwczovL3d3dy5lY3AuZ292LnBrL2NvbnRhY3QucGRmJyBjbGFzcz0nZGlyJyBzdHlsZT0nY3Vyc29yOiBwb2ludGVyOyc+RUNQIFNlY3JldGFyaWF0IE9mZmljZXJzIENvbnRhY3QgTnVtYmVyczwvYT48L2xpPjwvdWw+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwMjQnID4gSm9icyA8L2E+IDwvbGk+PC91bD5kAgMPZBYCAgMPFCsAAw8WCB4SUmVzb2x2ZWRSZW5kZXJNb2RlCylyVGVsZXJpay5XZWIuVUkuUmVuZGVyTW9kZSwgVGVsZXJpay5XZWIuVUksIFZlcnNpb249MjAxNS4xLjIyNS40NSwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj0xMjFmYWU3ODE2NWJhM2Q0AR4VRW5hYmxlRW1iZWRkZWRTY3JpcHRzZx4cRW5hYmxlRW1iZWRkZWRCYXNlU3R5bGVzaGVldGceF0VuYWJsZUFqYXhTa2luUmVuZGVyaW5naGQUKwAVDwIUZg8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUVfi9JbWFnZXMvbnZkMjAxN2MubXA0aAcAAAAAAAAAAAL/////DwUWfi9UaHVtbmFpbHMvbnZkcGljLmpwZwUeTmF0aW9uYWwgVm90ZXJzIERheSAyMDE3IFZpZGVvZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBRh+L0ltYWdlcy93b21lbm5pY3R2Yy5tcDRoBwAAAAAAAAAAAv////8PBSd+L1RodW1uYWlscy93b21lbm5pY3JlZ2lzdHJhdGlvbnBpYy5qcGcFFldvbWVuIE5JQyBSZWdpc3RyYXRpb25kZGQPBRRNZWRpYVBsYXllclZpZGVvRmlsZRQrAAkFJ34vSW1hZ2VzL1JlZ2lzdGVyIHlvdXJzZWxmIGFzIHZvdGVyLm1wNGgHAAAAAAAAAAAC/////w8FNX4vVGh1bW5haWxzLzUzQTY0MzZELTlGODctNDdCQy1CMDc3LUQwRTVBNjlBQTM3Ny5qcGVnBRpSZWdpc3RlciB5b3Vyc2VsZiBhcyBWb3RlcmRkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUVfi9JbWFnZXMvSU1HXzAyMTkuTVA0aAcAAAAAAAAAAAL/////DwU1fi9UaHVtbmFpbHMvRTNDOUI2RjAtRTkzMC00NUZELTg1RTAtODk5MDNDRDA2NTg4LmpwZWcFK1JlZ2lzdGVyIHlvdXIgdm90ZSAtIDI0dGggQXByaWwgKExhc3QgZGF0ZSlkZGQPBRRNZWRpYVBsYXllclZpZGVvRmlsZRQrAAkFIH4vSW1hZ2VzL1ZJRC0yMDE3MTExMC1XQTAwMjIubXA0aAcAAAAAAAAAAAL/////DwUjfi9UaHVtbmFpbHMvSU1HXzIwMTcxMTEwXzE4MDA0Ny5wbmcFLkhvbidibGUgQ0VDIGFkZHJlc3NpbmcgTkFEUkEgYW5kIEVDUCBvZmZpY2lhbHNkZGQPBRRNZWRpYVBsYXllclZpZGVvRmlsZRQrAAkFIH4vSW1hZ2VzL1ZpZGVvIC0gTW92aWUgMSAoMikubXA0aAcAAAAAAAAAAAL/////DwUWfi9UaHVtbmFpbHMvVk5EQ0VDLmpwZwVGSG9uJ2JsZSBDaGllZiBFbGVjdGlvbiBDb21taXNzaW9uZXIgc3BlZWNoIG9uIE5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNmRkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUgfi9JbWFnZXMvVmlkZW8gLSBNb3ZpZSAxICgzKS5tcDRoBwAAAAAAAAAAAv////8PBRx+L1RodW1uYWlscy9WTkRQcmVzaWRlbnQuanBnBThQcmVzaWRlbnQgb2YgUGFraXN0YW4gc3BlZWNoIG9uIE5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNmRkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUgfi9JbWFnZXMvVmlkZW8gLSBNb3ZpZSAxICgxKS5tcDRoBwAAAAAAAAAAAv////8PBRx+L1RodW1uYWlscy9WTkRTZWNyZXRhcnkuanBnBUxTZWNyZXRhcnkgRWxlY3Rpb24gQ29tbWlzc2lvbiBvZiBQYWtpc3RhbiBzcGVlY2ggb24gTmF0aW9uYWwgVm90ZXJzIERheSAyMDE2ZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBRN+L2ltYWdlcy9QdW5qYWIubXA0aAcAAAAAAAAAAAL/////DwUTfi9pbWFnZXMvcHVuamFiLnBuZwU2VHJhaW5pbmcgVmlkZW8gZm9yIFBvbGxpbmcgU3RhZmYgLSBMRyBFbGVjdGlvbnMgUHVuamFiZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBRJ+L2ltYWdlcy9TaW5kaC5tcDRoBwAAAAAAAAAAAv////8PBRJ+L2ltYWdlcy9TaW5kaC5wbmcFNVRyYWluaW5nIFZpZGVvIGZvciBQb2xsaW5nIFN0YWZmIC0gTEcgRWxlY3Rpb25zIFNpbmRoZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBRZ+L0ltYWdlcy9FVk1QYXNodG8ubXA0aAcAAAAAAAAAAAL/////DwUZfi9UaHVtbmFpbHMvZXZucGFzaHRvLmpwZwUoRWxlY3Ryb25pYyBWb3RpbmcgTWFjaGluZSBWaWRlbyAtIFBhc2h0b2RkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUUfi9JbWFnZXMvRVZNVXJkdS5tcDRoBwAAAAAAAAAAAv////8PBRl+L1RodW1uYWlscy9ldm5wYXNodG8uanBnBSZFbGVjdHJvbmljIFZvdGluZyBNYWNoaW5lIFZpZGVvIC0gVXJkdWRkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUVfi9JbWFnZXMvdm90ZXJkYXkubXA0aAcAAAAAAAAAAAL/////DwUZfi9UaHVtbmFpbHMvVm90ZXItRGF5LnBuZwU5U2VtaW5hciBvbiBWb3RlcidzIERheSAxNyBPY3RvYmVyIDIwMTIgYXQgRUNQIFNlY3JldGFyaWF0ZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBSB+L0ltYWdlcy8yMDEyXzEwXzE3XzA5XzA1XzUzLm1wNGgHAAAAAAAAAAAC/////w8FI34vVGh1bW5haWxzLzIwMTJfMTBfMTdfMDlfMDVfNTMucG5nBVpIb24nYmxlIENoaWVmIEp1c3RpY2Ugb2YgUGFraXN0YW4gY2hlY2tpbmcgaGlzIHZvdGUgLSAxN3RoIE9jdG9iZXIgMjAxMiBhdCBFQ1AgU2VjcmV0YXJpYXRkZGQPBRRNZWRpYVBsYXllclZpZGVvRmlsZRQrAAkFR34vSW1hZ2VzL0RHLUlUIEludGVydmlldyBHZW8gTmV3cyA5cG0gQnVsbGV0aW4gLSAyOXRoIGZlYnJ1YXJ5IDIwMTIubXA0aAcAAAAAAAAAAAL/////DwVGfi9UaHVtbmFpbHMvREctSVQgSW50ZXJ2aWV3IEdlbyBOZXdzIDlwbSBCdWxsZXRpbiAtIDI5dGggZmVicnVhcnkuanBlZwUrVm90ZXIgU01TIEluYXVndXJhdGlvbiAtIDI5dGggZmVicnVhcnkgMjAxMmRkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUjfi9JbWFnZXMvRmluYWwtVmlkZW8sIDIxLTctMjAxNy5tcDRoBwAAAAAAAAAAAv////8PBSh+L1RodW1uYWlscy9jZXJ0aWZpY2F0ZS1kaXN0cmlidXRpb24uanBnBRNFQ1AgQXdhcmRzIENlcmVtb255ZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBTB+L0ltYWdlcy9IaWdoZXN0IFNvY2lhbCBTZXJ2aWNlIEF3YXJkIChDbGlwKS5tcDRoBwAAAAAAAAAAAv////8PBSt+L1RodW1uYWlscy9IaWdoZXN0LVNvY2lhbC1TZXJ2aWNlLUF3YXIucG5nBUNIaWdoZXN0IFNvY2lhbCBTZXJ2aWNlIEF3YXJkIC0gMTd0aCBPY3RvYmVyIDIwMTIgYXQgRUNQIFNlY3JldGFyaWF0ZGRkDwUUTWVkaWFQbGF5ZXJWaWRlb0ZpbGUUKwAJBRZ+L0ltYWdlcy9ob3d0b3ZvdGUubXA0aAcAAAAAAAAAAAL/////DwUZfi9UaHVtbmFpbHMvaG93dG92b3RlLnBuZwUaSG93IHRvIGNhc3QgYSB2b3RlLi4uIDIwMDhkZGQPBRRNZWRpYVBsYXllclZpZGVvRmlsZRQrAAkFHX4vSW1hZ2VzL0ludGVyVmlldyxBd2FyZHMubXA0aAcAAAAAAAAAAAL/////DwUgfi9UaHVtbmFpbHMvSW50ZXJWaWV3LEF3YXJkcy5wbmcFJ0ludGVydmlldyBvZiBERy1JVCBFQ1AsIElDUFMgQXdhcmQgMjAxM2RkZA8FFE1lZGlhUGxheWVyVmlkZW9GaWxlFCsACQUVfi9JbWFnZXMvSU1HXzI4ODcubXA0aAcAAAAAAAAAAAL/////DwUYfi9UaHVtbmFpbHMvSU1HXzI4ODcucG5nBS1JQ1BTIElubm92YXRpdmUgdXNlIG9mIFRlY2hub2xvZ3kgQXdhcmQgMjAxMyBkZGQWBh4ETW9kZQspf1RlbGVyaWsuV2ViLlVJLk1lZGlhUGxheWVyUGxheWxpc3RNb2RlLCBUZWxlcmlrLldlYi5VSSwgVmVyc2lvbj0yMDE1LjEuMjI1LjQ1LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPTEyMWZhZTc4MTY1YmEzZDQBHghQb3NpdGlvbgspgwFUZWxlcmlrLldlYi5VSS5NZWRpYVBsYXllclBsYXlsaXN0UG9zaXRpb24sIFRlbGVyaWsuV2ViLlVJLCBWZXJzaW9uPTIwMTUuMS4yMjUuNDUsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MTIxZmFlNzgxNjViYTNkNAAeDkJ1dHRvbnNUcmlnZ2VyCymHAVRlbGVyaWsuV2ViLlVJLk1lZGlhUGxheWVyU2Nyb2xsQnV0dG9uc1RyaWdnZXIsIFRlbGVyaWsuV2ViLlVJLCBWZXJzaW9uPTIwMTUuMS4yMjUuNDUsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MTIxZmFlNzgxNjViYTNkNAAWCAIDD2QWCAIFDxQrAAIPFhIeDFNlbGVjdGlvbkVuZCgpW1N5c3RlbS5EZWNpbWFsLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODkBMB4TRW5hYmxlRW1iZWRkZWRTa2luc2ceBVZhbHVlKCsIATAfBWgeBFNraW4FB0RlZmF1bHQfBGceDlNlbGVjdGlvblN0YXJ0KCsIATAfAgsrBAEfA2dkZGQCBw8UKwACDxYSHwRnHwpnHwwFB0RlZmF1bHQfCygrCAEwHwkoKwgBMB8FaB8CCysEAR8DZx8NKCsIATBkZGQCCA8WAh4HVmlzaWJsZWhkAgkPFgIfDmhkAgQPDxYGHwVoHwwFB0RlZmF1bHQfCmdkZAIFDxQrAAYPFgweC18hRGF0YUJvdW5kZx4LXyFJdGVtQ291bnQCFB8FaB8DZx8EZx8CCysEAWQUKwADZGQUKwACFgIeEUl0ZW1QbGFjZUhvbGRlcklEBUJjdGwwMF9Db250ZW50UGxhY2VIb2xkZXIxX1JhZE1lZGlhUGxheWVyMV9QbGF5bGlzdF9pdGVtUGxhY2Vob2xkZXJkFCsAAw8FBl8hRFNJQwIUDwULXyFJdGVtQ291bnQCFA8FCF8hUENvdW50ZGQWAh4CX2NmZBYCZg9kFgJmD2QWAgIBD2QWKGYPFgIeDlNhdmVkT2xkVmFsdWVzFwAWAmYPZBYCZg8WAh4FdGl0bGUFHk5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNyBWaWRlbxYEZg9kFgJmDw8WBB4NQWx0ZXJuYXRlVGV4dAUWfi9UaHVtbmFpbHMvbnZkcGljLmpwZx4ISW1hZ2VVcmwFFn4vVGh1bW5haWxzL252ZHBpYy5qcGdkZAIBDxYCHglpbm5lcmh0bWwFHk5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNyBWaWRlb2QCAQ8WAh8TFwAWAmYPZBYCZg8WAh8UBRZXb21lbiBOSUMgUmVnaXN0cmF0aW9uFgRmD2QWAmYPDxYEHxUFJ34vVGh1bW5haWxzL3dvbWVubmljcmVnaXN0cmF0aW9ucGljLmpwZx8WBSd+L1RodW1uYWlscy93b21lbm5pY3JlZ2lzdHJhdGlvbnBpYy5qcGdkZAIBDxYCHxcFFldvbWVuIE5JQyBSZWdpc3RyYXRpb25kAgIPFgIfExcAFgJmD2QWAmYPFgIfFAUaUmVnaXN0ZXIgeW91cnNlbGYgYXMgVm90ZXIWBGYPZBYCZg8PFgQfFQU1fi9UaHVtbmFpbHMvNTNBNjQzNkQtOUY4Ny00N0JDLUIwNzctRDBFNUE2OUFBMzc3LmpwZWcfFgU1fi9UaHVtbmFpbHMvNTNBNjQzNkQtOUY4Ny00N0JDLUIwNzctRDBFNUE2OUFBMzc3LmpwZWdkZAIBDxYCHxcFGlJlZ2lzdGVyIHlvdXJzZWxmIGFzIFZvdGVyZAIDDxYCHxMXABYCZg9kFgJmDxYCHxQFK1JlZ2lzdGVyIHlvdXIgdm90ZSAtIDI0dGggQXByaWwgKExhc3QgZGF0ZSkWBGYPZBYCZg8PFgQfFQU1fi9UaHVtbmFpbHMvRTNDOUI2RjAtRTkzMC00NUZELTg1RTAtODk5MDNDRDA2NTg4LmpwZWcfFgU1fi9UaHVtbmFpbHMvRTNDOUI2RjAtRTkzMC00NUZELTg1RTAtODk5MDNDRDA2NTg4LmpwZWdkZAIBDxYCHxcFK1JlZ2lzdGVyIHlvdXIgdm90ZSAtIDI0dGggQXByaWwgKExhc3QgZGF0ZSlkAgQPFgIfExcAFgJmD2QWAmYPFgIfFAUuSG9uJ2JsZSBDRUMgYWRkcmVzc2luZyBOQURSQSBhbmQgRUNQIG9mZmljaWFscxYEZg9kFgJmDw8WBB8VBSN+L1RodW1uYWlscy9JTUdfMjAxNzExMTBfMTgwMDQ3LnBuZx8WBSN+L1RodW1uYWlscy9JTUdfMjAxNzExMTBfMTgwMDQ3LnBuZ2RkAgEPFgIfFwUySG9uJiMzOTtibGUgQ0VDIGFkZHJlc3NpbmcgTkFEUkEgYW5kIEVDUCBvZmZpY2lhbHNkAgUPFgIfExcAFgJmD2QWAmYPFgIfFAVGSG9uJ2JsZSBDaGllZiBFbGVjdGlvbiBDb21taXNzaW9uZXIgc3BlZWNoIG9uIE5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNhYEZg9kFgJmDw8WBB8VBRZ+L1RodW1uYWlscy9WTkRDRUMuanBnHxYFFn4vVGh1bW5haWxzL1ZORENFQy5qcGdkZAIBDxYCHxcFSkhvbiYjMzk7YmxlIENoaWVmIEVsZWN0aW9uIENvbW1pc3Npb25lciBzcGVlY2ggb24gTmF0aW9uYWwgVm90ZXJzIERheSAyMDE2ZAIGDxYCHxMXABYCZg9kFgJmDxYCHxQFOFByZXNpZGVudCBvZiBQYWtpc3RhbiBzcGVlY2ggb24gTmF0aW9uYWwgVm90ZXJzIERheSAyMDE2FgRmD2QWAmYPDxYEHxUFHH4vVGh1bW5haWxzL1ZORFByZXNpZGVudC5qcGcfFgUcfi9UaHVtbmFpbHMvVk5EUHJlc2lkZW50LmpwZ2RkAgEPFgIfFwU4UHJlc2lkZW50IG9mIFBha2lzdGFuIHNwZWVjaCBvbiBOYXRpb25hbCBWb3RlcnMgRGF5IDIwMTZkAgcPFgIfExcAFgJmD2QWAmYPFgIfFAVMU2VjcmV0YXJ5IEVsZWN0aW9uIENvbW1pc3Npb24gb2YgUGFraXN0YW4gc3BlZWNoIG9uIE5hdGlvbmFsIFZvdGVycyBEYXkgMjAxNhYEZg9kFgJmDw8WBB8VBRx+L1RodW1uYWlscy9WTkRTZWNyZXRhcnkuanBnHxYFHH4vVGh1bW5haWxzL1ZORFNlY3JldGFyeS5qcGdkZAIBDxYCHxcFTFNlY3JldGFyeSBFbGVjdGlvbiBDb21taXNzaW9uIG9mIFBha2lzdGFuIHNwZWVjaCBvbiBOYXRpb25hbCBWb3RlcnMgRGF5IDIwMTZkAggPFgIfExcAFgJmD2QWAmYPFgIfFAU2VHJhaW5pbmcgVmlkZW8gZm9yIFBvbGxpbmcgU3RhZmYgLSBMRyBFbGVjdGlvbnMgUHVuamFiFgRmD2QWAmYPDxYEHxUFE34vaW1hZ2VzL3B1bmphYi5wbmcfFgUTfi9pbWFnZXMvcHVuamFiLnBuZ2RkAgEPFgIfFwU2VHJhaW5pbmcgVmlkZW8gZm9yIFBvbGxpbmcgU3RhZmYgLSBMRyBFbGVjdGlvbnMgUHVuamFiZAIJDxYCHxMXABYCZg9kFgJmDxYCHxQFNVRyYWluaW5nIFZpZGVvIGZvciBQb2xsaW5nIFN0YWZmIC0gTEcgRWxlY3Rpb25zIFNpbmRoFgRmD2QWAmYPDxYEHxUFEn4vaW1hZ2VzL1NpbmRoLnBuZx8WBRJ+L2ltYWdlcy9TaW5kaC5wbmdkZAIBDxYCHxcFNVRyYWluaW5nIFZpZGVvIGZvciBQb2xsaW5nIFN0YWZmIC0gTEcgRWxlY3Rpb25zIFNpbmRoZAIKDxYCHxMXABYCZg9kFgJmDxYCHxQFKEVsZWN0cm9uaWMgVm90aW5nIE1hY2hpbmUgVmlkZW8gLSBQYXNodG8WBGYPZBYCZg8PFgQfFQUZfi9UaHVtbmFpbHMvZXZucGFzaHRvLmpwZx8WBRl+L1RodW1uYWlscy9ldm5wYXNodG8uanBnZGQCAQ8WAh8XBShFbGVjdHJvbmljIFZvdGluZyBNYWNoaW5lIFZpZGVvIC0gUGFzaHRvZAILDxYCHxMXABYCZg9kFgJmDxYCHxQFJkVsZWN0cm9uaWMgVm90aW5nIE1hY2hpbmUgVmlkZW8gLSBVcmR1FgRmD2QWAmYPDxYEHxUFGX4vVGh1bW5haWxzL2V2bnBhc2h0by5qcGcfFgUZfi9UaHVtbmFpbHMvZXZucGFzaHRvLmpwZ2RkAgEPFgIfFwUmRWxlY3Ryb25pYyBWb3RpbmcgTWFjaGluZSBWaWRlbyAtIFVyZHVkAgwPFgIfExcAFgJmD2QWAmYPFgIfFAU5U2VtaW5hciBvbiBWb3RlcidzIERheSAxNyBPY3RvYmVyIDIwMTIgYXQgRUNQIFNlY3JldGFyaWF0FgRmD2QWAmYPDxYEHxUFGX4vVGh1bW5haWxzL1ZvdGVyLURheS5wbmcfFgUZfi9UaHVtbmFpbHMvVm90ZXItRGF5LnBuZ2RkAgEPFgIfFwU9U2VtaW5hciBvbiBWb3RlciYjMzk7cyBEYXkgMTcgT2N0b2JlciAyMDEyIGF0IEVDUCBTZWNyZXRhcmlhdGQCDQ8WAh8TFwAWAmYPZBYCZg8WAh8UBVpIb24nYmxlIENoaWVmIEp1c3RpY2Ugb2YgUGFraXN0YW4gY2hlY2tpbmcgaGlzIHZvdGUgLSAxN3RoIE9jdG9iZXIgMjAxMiBhdCBFQ1AgU2VjcmV0YXJpYXQWBGYPZBYCZg8PFgQfFQUjfi9UaHVtbmFpbHMvMjAxMl8xMF8xN18wOV8wNV81My5wbmcfFgUjfi9UaHVtbmFpbHMvMjAxMl8xMF8xN18wOV8wNV81My5wbmdkZAIBDxYCHxcFXkhvbiYjMzk7YmxlIENoaWVmIEp1c3RpY2Ugb2YgUGFraXN0YW4gY2hlY2tpbmcgaGlzIHZvdGUgLSAxN3RoIE9jdG9iZXIgMjAxMiBhdCBFQ1AgU2VjcmV0YXJpYXRkAg4PFgIfExcAFgJmD2QWAmYPFgIfFAUrVm90ZXIgU01TIEluYXVndXJhdGlvbiAtIDI5dGggZmVicnVhcnkgMjAxMhYEZg9kFgJmDw8WBB8VBUZ+L1RodW1uYWlscy9ERy1JVCBJbnRlcnZpZXcgR2VvIE5ld3MgOXBtIEJ1bGxldGluIC0gMjl0aCBmZWJydWFyeS5qcGVnHxYFRn4vVGh1bW5haWxzL0RHLUlUIEludGVydmlldyBHZW8gTmV3cyA5cG0gQnVsbGV0aW4gLSAyOXRoIGZlYnJ1YXJ5LmpwZWdkZAIBDxYCHxcFK1ZvdGVyIFNNUyBJbmF1Z3VyYXRpb24gLSAyOXRoIGZlYnJ1YXJ5IDIwMTJkAg8PFgIfExcAFgJmD2QWAmYPFgIfFAUTRUNQIEF3YXJkcyBDZXJlbW9ueRYEZg9kFgJmDw8WBB8VBSh+L1RodW1uYWlscy9jZXJ0aWZpY2F0ZS1kaXN0cmlidXRpb24uanBnHxYFKH4vVGh1bW5haWxzL2NlcnRpZmljYXRlLWRpc3RyaWJ1dGlvbi5qcGdkZAIBDxYCHxcFE0VDUCBBd2FyZHMgQ2VyZW1vbnlkAhAPFgIfExcAFgJmD2QWAmYPFgIfFAVDSGlnaGVzdCBTb2NpYWwgU2VydmljZSBBd2FyZCAtIDE3dGggT2N0b2JlciAyMDEyIGF0IEVDUCBTZWNyZXRhcmlhdBYEZg9kFgJmDw8WBB8VBSt+L1RodW1uYWlscy9IaWdoZXN0LVNvY2lhbC1TZXJ2aWNlLUF3YXIucG5nHxYFK34vVGh1bW5haWxzL0hpZ2hlc3QtU29jaWFsLVNlcnZpY2UtQXdhci5wbmdkZAIBDxYCHxcFQ0hpZ2hlc3QgU29jaWFsIFNlcnZpY2UgQXdhcmQgLSAxN3RoIE9jdG9iZXIgMjAxMiBhdCBFQ1AgU2VjcmV0YXJpYXRkAhEPFgIfExcAFgJmD2QWAmYPFgIfFAUaSG93IHRvIGNhc3QgYSB2b3RlLi4uIDIwMDgWBGYPZBYCZg8PFgQfFQUZfi9UaHVtbmFpbHMvaG93dG92b3RlLnBuZx8WBRl+L1RodW1uYWlscy9ob3d0b3ZvdGUucG5nZGQCAQ8WAh8XBRpIb3cgdG8gY2FzdCBhIHZvdGUuLi4gMjAwOGQCEg8WAh8TFwAWAmYPZBYCZg8WAh8UBSdJbnRlcnZpZXcgb2YgREctSVQgRUNQLCBJQ1BTIEF3YXJkIDIwMTMWBGYPZBYCZg8PFgQfFQUgfi9UaHVtbmFpbHMvSW50ZXJWaWV3LEF3YXJkcy5wbmcfFgUgfi9UaHVtbmFpbHMvSW50ZXJWaWV3LEF3YXJkcy5wbmdkZAIBDxYCHxcFJ0ludGVydmlldyBvZiBERy1JVCBFQ1AsIElDUFMgQXdhcmQgMjAxM2QCEw8WAh8TFwAWAmYPZBYCZg8WAh8UBS1JQ1BTIElubm92YXRpdmUgdXNlIG9mIFRlY2hub2xvZ3kgQXdhcmQgMjAxMyAWBGYPZBYCZg8PFgQfFQUYfi9UaHVtbmFpbHMvSU1HXzI4ODcucG5nHxYFGH4vVGh1bW5haWxzL0lNR18yODg3LnBuZ2RkAgEPFgIfFwUtSUNQUyBJbm5vdmF0aXZlIHVzZSBvZiBUZWNobm9sb2d5IEF3YXJkIDIwMTMgZAIGD2QWBGYPDxYMHwwFB0RlZmF1bHQfCmcfA2cfBGcfAgsrBAEfBWhkZAICDxYCHwFlZAIEDxYCHwEFtg48ZGl2IGNsYXNzPSdzcGFuMic+PGRpdiBjbGFzcz0nYm94LTEnPjxoND5BYm91dCBFQ1A8L2g0Pjx1bD48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTIxJz5PdmVydmlldyBvZiBFQ1A8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTIyJz5Ib25vdXJhYmxlIENFQzwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjMnPkhvbm91cmFibGUgTWVtYmVyczwvYT48L2xpPjxsaT48YSBocmVmPScvY29udGFjdC5wZGYnPk9mZmljZXJzPC9hPjwvbGk+PC91bD48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzPSdzcGFuMic+PGRpdiBjbGFzcz0nYm94LTEnPjxoND5Gb3IgVm90ZXJzPC9oND48dWw+PGxpPjxhIGhyZWY9Jy9mcm1HZW5lcmljUGFnZS5hc3B4P1BhZ2VJRD00Jz5Ib3cgdG8gUmVnaXN0ZXI8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI5Jz5DaGVjayBZb3VyIFJlZ2lzdHJhdGlvbjwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjUnPkZBUXM8L2E+PC9saT48L3VsPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3M9J3NwYW4yJz48ZGl2IGNsYXNzPSdib3gtMSc+PGg0PkVsZWN0aW9uczwvaDQ+PHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzA1MSc+R2VuZXJhbCBFbGVjdGlvbnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwNDMnPkxHIEVsZWN0aW9uczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjcnPkVsZWN0aW9uIExhd3M8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTI2Jz5EZWxpbWl0YXRpb248L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMwNDcnPkVsZWN0b3JhbCBSb2xsczwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MzEwNCc+UGFydHkgUG9zaXRpb248L2E+PC9saT48L3VsPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3M9J3NwYW4yJz48ZGl2IGNsYXNzPSdib3gtMSc+PGg0Pk1lZGlhIEVDUDwvaDQ+PHVsPjxsaT48YSBocmVmPScvUHJlc3NSZWxlYXNlcy5hc3B4Jz5QcmVzcyBSZWxlYXNlczwvYT48L2xpPjxsaT48YSBocmVmPScvTmV3c2xldHRlcnMuYXNweCc+TmV3c2xldHRlcnMvUHVibGljYXRpb25zPC9hPjwvbGk+PGxpPjxhIGhyZWY9Jy9Ob3RpZmljYXRpb25zLmFzcHgnPk5vdGlmaWNhdGlvbnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUV2ZW50c0dhbGxlcnkuYXNweCc+SW1hZ2UgR2FsbGVyeTwvYT48L2xpPjxsaT48YSBocmVmPScvZnJtdmlkZW9nYWxsZXJ5LmFzcHgnPlZpZGVvIEdhbGxlcnk8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMxNTcnPlRyYWluaW5nIE1hdGVyaWFsPC9hPjwvbGk+PC91bD48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzPSdzcGFuMic+PGRpdiBjbGFzcz0nYm94LTEnPjxoND5NaXNjLjwvaDQ+PHVsPjxsaT48YSBocmVmPScvZnJtR2VuZXJpY1BhZ2UuYXNweD9QYWdlSUQ9MjgnPlRlbmRlcnM8L2E+PC9saT48bGk+PGEgaHJlZj0nL2ZybUdlbmVyaWNQYWdlLmFzcHg/UGFnZUlEPTMxNDgnPkNvbnRhY3QgVXM8L2E+PC9saT48bGk+PGEgaHJlZj0naHR0cHM6Ly93d3cuZWNwLmdvdi5way9jb250YWN0LnBkZic+RUNQIFNlY3JldGFyaWF0IE9mZmljZXJzIENvbnRhY3QgTnVtYmVyczwvYT48L2xpPjwvdWw+PC9kaXY+PC9kaXY+ZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WBQUpY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRSYWRNZWRpYVBsYXllcjEFPmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkUmFkTWVkaWFQbGF5ZXIxJFRvb2xiYXIkUHJvZ3Jlc3NSYWlsBT9jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJFJhZE1lZGlhUGxheWVyMSRUb29sYmFyJFZvbHVtZUNvbnRyb2wFMmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkUmFkTWVkaWFQbGF5ZXIxJFBsYXlsaXN0BT5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJFJhZE1lZGlhUGxheWVyMSRUaXRsZWJhciRTb2NpYWxTaGFyZYm6J6AKVx4mDXKN50SjW591AOBcI57+F9/8BBr9Vqds" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=9Q3Tw_ROuEL9S04FtdLl2H6opHHLhfOMojp_etOpjpORq31YnZDSqa5xlUjEAbNdtZzacgftYH6U1qJNiOd5L4yxZkJc2kdDRjjirvgm6sk1&amp;t=636042899952281841" type="text/javascript"></script>


<script src="/Telerik.Web.UI.WebResource.axd?_TSM_HiddenField_=ContentPlaceHolder1_RadScriptManager1_TSM&amp;compress=1&amp;_TSM_CombinedScripts_=%3b%3bSystem.Web.Extensions%2c+Version%3d4.0.0.0%2c+Culture%3dneutral%2c+PublicKeyToken%3d31bf3856ad364e35%3aen-US%3af9ecfe64-7d94-4875-a470-9996e4d00a9f%3aea597d4b%3ab25378d2%3bTelerik.Web.UI%2c+Version%3d2015.1.225.45%2c+Culture%3dneutral%2c+PublicKeyToken%3d121fae78165ba3d4%3aen-US%3ad3cd47d0-4d93-4bad-8b9f-f9fea0aa4c69%3a16e4e7cd%3af7645509%3a24ee1bba%3ac128760b%3a6ec8ee1b%3a874f8ea2%3a88144a7a%3a1e771326%3af9b9258%3aed16cbdc%3addbfcb67%3afd9da3ae" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="66CFF204" />
</div>
        <div>

            <!--Wrapper Start-->
            <div id="wrapper">
                <!--Headre Start-->
                <header id="header">
                    <!--Head Topbar Start-->
                    <div class="head-topbar-Green">
                        <div class="container">
                            <div class="row-fluid">
                                <div id="ECPHeading" class="left">
                                <ul class="header-social">
                                            <li><img src=' ./images/1.png' /></li>           
                                </ul>
                                </div>
                                
                            </div>
                        </div>
                    </div> 

               
           
            <!--Head Topbar End-->
            <!--Menu Row Start-->
            <div class="menu-row">
                <div class="container">
                    <div class="row-fluid">
                        <strong class="logo"><a href="default.aspx">
                            <img src=' ./images/logo.png' alt="img"></a></strong>
                    </div>
                </div>
                <!--Navigation Area	Start-->
               
                <section class="navigation-area">
 <div id="list1">
                    <div class="container">
                        <div class="row-fluid">
                            <!--Navbar Start-->
                            <div class="navbar margin-none">
                                <div class="container">
                                    <button data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar" type="button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                                    <div class="nav-collapse collapse">
                                       <div id="navbar">
                                            <ul id='nav'>
											<li><a href='default.php' > Home </a> </li>
											<li><a href='/#' > About ECP </a> 
											<ul>
											<li><a href='Overview.php' class='dir' style='cursor: pointer;'>Overview of ECP</a></li>
											<li><a href='HonourableCEC.php' class='dir' style='cursor: pointer;'>Honourable CEC</a></li>
											<li><a href='HonourableMember.php' class='dir' style='cursor: pointer;'>Honourable Members</a></li>
											<li><a href='contact.pdf' class='dir' style='cursor: pointer;'>Officers</a></li>
											</ul>
											</li>
											<li><a href='login.php' class='dir' style='cursor: pointer;'>For Officers</a></li>
											<li><a href='/#' > For Voters </a> 
											<ul>
											<li><a href='HowtoRegister.php' class='dir' style='cursor: pointer;'>How to Register</a></li>
											<li><a href='CheckRegistration.php' class='dir' style='cursor: pointer;'>Check Your Registration</a></li>
											<li><a href='FAQs.php' class='dir' style='cursor: pointer;'>FAQs</a></li>
											</ul>
											</li>
											<li><a href='/#' > Elections </a> <ul><li><a href='generalelection.php' class='dir' style='cursor: pointer;'>General Elections</a></li><li><a href='lgelection.php' class='dir' style='cursor: pointer;'>LG Elections</a></li><li><a href='electionlaws.php' class='dir' style='cursor: pointer;'>Election Laws</a></li><li><a href='delimitation.php' class='dir' style='cursor: pointer;'>Delimitation</a></li><li><a href='electoralrolls.php' class='dir' style='cursor: pointer;'>Electoral Rolls</a></li><li><a href='partyposition.php' class='dir' style='cursor: pointer;'>Party Position</a></li></ul></li><li><a href='/#' > Media ECP </a> <ul><li><a href='PressRelease.php' class='dir' style='cursor: pointer;'>Press Releases</a></li><li><a href='Newsletters.php' class='dir' style='cursor: pointer;'>Newsletters/Publications</a></li><li><a href='Notifications.php' class='dir' style='cursor: pointer;'>Notifications</a></li><li><a href='imagegallery.php' class='dir' style='cursor: pointer;'>Image Gallery</a></li><li><a href='videogallery.php' class='dir' style='cursor: pointer;'>Video Gallery</a></li><li><a href='/frmGenericPage.aspx?PageID=3157' class='dir' style='cursor: pointer;'>Training Material</a></li></ul></li><li><a href='/#' > Parties & Candidates </a> <ul><li><a href='listofpoliticalparties.php' class='dir' style='cursor: pointer;'>List of Political Parties</a></li><li><a href='listofallsymbols.php' class='dir' style='cursor: pointer;'>List of all symbols</a></li><li><a href='availablesymbols.php' class='dir' style='cursor: pointer;'>Available Symbols</a></li></ul></li><li><a href='/frmGenericPage.aspx?PageID=24' > Downloads </a> </li><li><a href='/#' > Misc. </a> <ul><li><a href='/frmGenericPage.aspx?PageID=28' class='dir' style='cursor: pointer;'>Tenders</a></li><li><a href='/frmGenericPage.aspx?PageID=3148' class='dir' style='cursor: pointer;'>Contact Us</a></li><li><a href='https://www.ecp.gov.pkcontact.pdf' class='dir' style='cursor: pointer;'>ECP Secretariat Officers Contact Numbers</a></li></ul></li><li><a href='/frmGenericPage.aspx?PageID=3024' > Jobs </a> </li></ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <!--Navbar End-->
                        </div>
                    </div>
</div>
                </section>
                    
                <!--Navigation Area	End-->
            </div>
            <!--Menu Row End-->
            </header>
  <!--Headre End-->
            <div id="main">
                <!--Banner Start-->
                <div id="banner">
                    <div id="inner-banner">
                        <div class="container">
                            
     <h1 id="ContentPlaceHolder2_lblTitle">Video Gallery</h1>
    <p id="ContentPlaceHolder2_lblTitle12"></p>

                        </div>
                    </div>
                </div>
                <!--Banner End-->

                <!--Blog Page Start-->

                <section class="blog-page">
                    <div class="container">

                        <div class="row-fluid">
                            <div class="span9">
                                <div class="blog-content">
                                    <!--Photo Post Start-->
                                    
    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ContentPlaceHolder1$RadScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>

    <div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1" class="RadMediaPlayer RadMediaPlayer_Default" Text="RadMediaPlayer" style="width:100%;">
	<!-- 2015.1.225.45 --><div class="rmpSubtitles">
		<span class="rmpSubtitlesInner" style="display:none;"></span>
	</div><div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Overlay" class="rmpOverlay" style="position:absolute;height:100%;width:100%;">

	</div><button id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_PlayButtonCenter" type="button" class="rmpActionButton rmpBigPlayButton" title=""><span class="rmpIcon rmpBigPlayIcon"></span><span class="rmpButtonText">Play</span></button><div class="rmpToolbarWrapper" id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_Wrapper">
		<div class="rmpToolbar">
			<div class="rmpLeftControlsSet">
				<button id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_PlayButton" type="button" class="rmpActionButton rmpPlayButton" title=""><span class="rmpIcon rmpPlayIcon"></span><span class="rmpButtonText">Play</span></button>
			</div><div class="rmpSeekBar">
				<div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail" class="RadSlider RadSlider_Default" style="height:22px;width:50px;">
					<div id="RadSliderWrapper_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail" class="rslHorizontal " style="height:22px;">
						<div id="RadSliderTrack_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail" class="rslTrack" style="left:0px;width:50px;">
							<div id="RadSliderSelected_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail" class="rslSelectedregion">
								<!-- -->
							</div><a id="RadSliderDrag_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail" href="#" class="rslDraghandle" title="Drag"><span>Drag</span></a>
						</div>
					</div><input id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail_ClientState" name="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail_ClientState" type="hidden" />
				</div>
			</div><div class="rmpRightControlsSet">
				<span class="rmpProgressText"><span id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_CurrentTimeDisplay" class="rmpCurrentTime">0:00</span> / <span id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_DurationDisplay" class="rmpDurationTime">0:00</span></span><div class="rmpVolContr">
					<button id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControlButton" type="button" class="rmpActionButton rmpVolumeButton" title="Mute"><span class="rmpIcon rmpVolumeIcon"></span><span class="rmpButtonText">Volume</span></button><div class="rmpVolContrBar" style="display:none;">
						<div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl" class="RadSlider RadSlider_Default" style="height:80px;width:22px;">
							<div id="RadSliderWrapper_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl" class="rslVertical " style="height:80px;">
								<div id="RadSliderTrack_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl" class="rslTrack" style="top:0px;height:80px;">
									<div id="RadSliderSelected_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl" class="rslSelectedregion">
										<!-- -->
									</div><a id="RadSliderDrag_ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl" href="#" class="rslDraghandle" title="Drag"><span>Drag</span></a>
								</div>
							</div><input id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl_ClientState" name="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl_ClientState" type="hidden" />
						</div>
					</div>
				</div><button id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_FSButton" type="button" class="rmpActionButton rmpFullScrButton" title="Full Screen"><span class="rmpIcon rmpFullScrIcon"></span><span class="rmpButtonText">Full Screen</span></button>
			</div>
		</div>
	</div><div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_LoadingIndicator" class="RadAjax RadAjax_Default" style="display:none;">
		<div class="raDiv">

		</div><div class="raColor raTransp">

		</div>
	</div><div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_Layout" class="rmpPlaylist rmpPlaylistHorizontal rmpPlaylistNavButtons">
		<div class="rmpPlaylistPrevButtonWrap"><button class="rmpActionButton rmpPlaylistPrevButton"><span class="rmpIcon rmpPlaylistPrevIcon"></span><span class="rmpButtonText">Prev</span></button></div><ul id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_ItemsList"><li class="rmpActive"><a href="#" title="National Voters Day 2017 Video"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/nvdpic.jpg" alt="~/Thumnails/nvdpic.jpg" /></span><span class="rmpTitle">National Voters Day 2017 Video</span></a></li><li><a href="#" title="Women NIC Registration"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/womennicregistrationpic.jpg" alt="~/Thumnails/womennicregistrationpic.jpg" /></span><span class="rmpTitle">Women NIC Registration</span></a></li><li><a href="#" title="Register yourself as Voter"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/53A6436D-9F87-47BC-B077-D0E5A69AA377.jpeg" alt="~/Thumnails/53A6436D-9F87-47BC-B077-D0E5A69AA377.jpeg" /></span><span class="rmpTitle">Register yourself as Voter</span></a></li><li><a href="#" title="Register your vote - 24th April (Last date)"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/E3C9B6F0-E930-45FD-85E0-89903CD06588.jpeg" alt="~/Thumnails/E3C9B6F0-E930-45FD-85E0-89903CD06588.jpeg" /></span><span class="rmpTitle">Register your vote - 24th April (Last date)</span></a></li><li><a href="#" title="Hon&#39;ble CEC addressing NADRA and ECP officials"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/IMG_20171110_180047.png" alt="~/Thumnails/IMG_20171110_180047.png" /></span><span class="rmpTitle">Hon&#39;ble CEC addressing NADRA and ECP officials</span></a></li><li><a href="#" title="Hon&#39;ble Chief Election Commissioner speech on National Voters Day 2016"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/VNDCEC.jpg" alt="~/Thumnails/VNDCEC.jpg" /></span><span class="rmpTitle">Hon&#39;ble Chief Election Commissioner speech on National Voters Day 2016</span></a></li><li><a href="#" title="President of Pakistan speech on National Voters Day 2016"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/VNDPresident.jpg" alt="~/Thumnails/VNDPresident.jpg" /></span><span class="rmpTitle">President of Pakistan speech on National Voters Day 2016</span></a></li><li><a href="#" title="Secretary Election Commission of Pakistan speech on National Voters Day 2016"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/VNDSecretary.jpg" alt="~/Thumnails/VNDSecretary.jpg" /></span><span class="rmpTitle">Secretary Election Commission of Pakistan speech on National Voters Day 2016</span></a></li><li><a href="#" title="Training Video for Polling Staff - LG Elections Punjab"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="images/punjab.png" alt="~/images/punjab.png" /></span><span class="rmpTitle">Training Video for Polling Staff - LG Elections Punjab</span></a></li><li><a href="#" title="Training Video for Polling Staff - LG Elections Sindh"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="images/Sindh.png" alt="~/images/Sindh.png" /></span><span class="rmpTitle">Training Video for Polling Staff - LG Elections Sindh</span></a></li><li><a href="#" title="Electronic Voting Machine Video - Pashto"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/evnpashto.jpg" alt="~/Thumnails/evnpashto.jpg" /></span><span class="rmpTitle">Electronic Voting Machine Video - Pashto</span></a></li><li><a href="#" title="Electronic Voting Machine Video - Urdu"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/evnpashto.jpg" alt="~/Thumnails/evnpashto.jpg" /></span><span class="rmpTitle">Electronic Voting Machine Video - Urdu</span></a></li><li><a href="#" title="Seminar on Voter&#39;s Day 17 October 2012 at ECP Secretariat"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/Voter-Day.png" alt="~/Thumnails/Voter-Day.png" /></span><span class="rmpTitle">Seminar on Voter&#39;s Day 17 October 2012 at ECP Secretariat</span></a></li><li><a href="#" title="Hon&#39;ble Chief Justice of Pakistan checking his vote - 17th October 2012 at ECP Secretariat"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/2012_10_17_09_05_53.png" alt="~/Thumnails/2012_10_17_09_05_53.png" /></span><span class="rmpTitle">Hon&#39;ble Chief Justice of Pakistan checking his vote - 17th October 2012 at ECP Secretariat</span></a></li><li><a href="#" title="Voter SMS Inauguration - 29th february 2012"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/DG-IT%20Interview%20Geo%20News%209pm%20Bulletin%20-%2029th%20february.jpeg" alt="~/Thumnails/DG-IT Interview Geo News 9pm Bulletin - 29th february.jpeg" /></span><span class="rmpTitle">Voter SMS Inauguration - 29th february 2012</span></a></li><li><a href="#" title="ECP Awards Ceremony"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/certificate-distribution.jpg" alt="~/Thumnails/certificate-distribution.jpg" /></span><span class="rmpTitle">ECP Awards Ceremony</span></a></li><li><a href="#" title="Highest Social Service Award - 17th October 2012 at ECP Secretariat"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/Highest-Social-Service-Awar.png" alt="~/Thumnails/Highest-Social-Service-Awar.png" /></span><span class="rmpTitle">Highest Social Service Award - 17th October 2012 at ECP Secretariat</span></a></li><li><a href="#" title="How to cast a vote... 2008"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/howtovote.png" alt="~/Thumnails/howtovote.png" /></span><span class="rmpTitle">How to cast a vote... 2008</span></a></li><li><a href="#" title="Interview of DG-IT ECP, ICPS Award 2013"><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/InterView,Awards.png" alt="~/Thumnails/InterView,Awards.png" /></span><span class="rmpTitle">Interview of DG-IT ECP, ICPS Award 2013</span></a></li><li><a href="#" title="ICPS Innovative use of Technology Award 2013 "><span class="rmpThumbWrap"><img class="rmpListItemThumb" src="Thumnails/IMG_2887.png" alt="~/Thumnails/IMG_2887.png" /></span><span class="rmpTitle">ICPS Innovative use of Technology Award 2013 </span></a></li></ul><div class="rmpPlaylistNextButtonWrap"><button class="rmpActionButton rmpPlaylistNextButton"><span class="rmpIcon rmpPlaylistNextIcon"></span><span class="rmpButtonText">Next</span></button></div>
	</div><input id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_ClientState" name="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_ClientState" type="hidden" /><span id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist" style="display:none;"></span><div class="rmpTitleBar" id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_Wrapper">
		<h4>

		</h4><div class="rmpButtSet">
			<button id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialButton" type="button" class="rmpActionButton rmpShareButton" title=""><span class="rmpIcon rmpShareIcon"></span><span class="rmpButtonText">Share</span></button><button type="button" title="Open Playlist" class="rmpActionButton rmpOpenPlaylistButton"><span class="rmpIcon rmpOpenPlaylistIcon"></span><span class="rmpButtonText">Open Playlist</span></button><button type="button" title="Close Playlist" class="rmpActionButton rmpClosePlaylistButton" style="display:none;"><span class="rmpIcon rmpClosePlaylistIcon"></span><span class="rmpButtonText">Close Playlist</span></button><div class="rmpSocialShareBar" style="display:none;">
				<div id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialShare" class="RadSocialShare RadSocialShare_Default sshVerticalMode">
					<ul class="sshContent">
						<li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on GoogleBookmarks"><span class="sshIcon sshGoogleBookmarks "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Facebook"><span class="sshIcon sshShareOnFacebook "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Tweet this"><span class="sshIcon sshShareOnTwitter "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Digg"><span class="sshIcon sshDigg "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Tumblr"><span class="sshIcon sshTumblr "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on StumbleUpon"><span class="sshIcon sshStumbleUpon "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Reddit"><span class="sshIcon sshReddit "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on LinkedIn"><span class="sshIcon sshLinkedIn "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Delicious"><span class="sshIcon sshDelicious "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on Blogger"><span class="sshIcon sshBlogger "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on MySpace"><span class="sshIcon sshMySpace "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Share on GoogleBookmarks"><span class="sshIcon sshGoogleBookmarks "></span></a></li><li class="sshListItem"><a class="sshLinkItem" href="javascript:void(0)" title="Tell a friend"><span class="sshIcon sshMailTo "></span></a></li>
					</ul><input id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialShare_ClientState" name="ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialShare_ClientState" type="hidden" />
				</div>
			</div>
		</div>
	</div><input id="ctl00_ContentPlaceHolder1_RadMediaPlayer1_ClientState" name="ctl00_ContentPlaceHolder1_RadMediaPlayer1_ClientState" type="hidden" />
</div>


                                    <!--Photo Post End-->
                                </div>
                            </div>
                            <div class="span3">
                                <!--Sidebar Start-->
                                <aside>
                                    <div id="sidebar">
                                        <form action="#" class="sidebar-form">
                                            
                                            
                                            <div class="sidebar-member"><a href="frmGenericPage.aspx?PageID=3036" class="member-icon2"><i class="fa fa-user"></i></a><a href="frmGenericPage.aspx?PageID=3036" class="member-text2">Check your vote</a> </div>
                                        </form>
                                        <!--Sidebar Upcoming News Box Start-->
                                        <div class="sidebar-recent-post">
                                           
                                            
                                        </div>
                                        <!--Sidebar Upcoming News Box End-->
                                        <!--Sidebar Related Links Box Start-->
                                        <div class="sidebar-recent-post">
                                            <h3>Related Links</h3>
                                            <div class="list-area">
                                                <ul>
                                                    <li><a href="frmGenericPage.aspx?PageID=27"><span></span>Election Laws</a></li>
                                                    <li><a href="frmGenericPage.aspx?PageID=3089"><span></span>List of Political Parties</a></li>
                                                   
                                                    <li><a href="frmGenericPage.aspx?PageID=3090"><span></span>Symbols Allotted to Political Parties</a></li>
                                                    <li><a href="frmGenericPage.aspx?PageID=25"><span></span>FAQs</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!--Sidebar Related Links Box End-->
                                    </div>
                                </aside>
                                <!--Sidebar End-->
                            </div>
                        </div>
                    </div>
                </section>
                <!--Blog Page End-->

                <!--Footer Start-->
                <section id="footer">
                    <!--Footer Top Start-->
                    <div class="footer-top">
                        <div class="container">
                            <div class="row-fluid">
                                <div class="span2">
                                    <div class="box-1 box-first">

                                        <div>
                                            <strong class="footer-logo"><a href="#">ECP</a></strong>

                                        </div>

                                    </div>
                                </div>
                                <div class='span2'><div class='box-1'><h4>About ECP</h4><ul><li><a href='Overview.php'>Overview of ECP</a></li><li><a href='HonourableCEC.php'>Honourable CEC</a></li><li><a href='HonourableMember.php'>Honourable Members</a></li><li><a href='contact.pdf'>Officers</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>For Voters</h4><ul><li><a href='HowtoRegister.php'>How to Register</a></li><li><a href='CheckRegistration.php'>Check Your Registration</a></li><li><a href='FAQs.php'>FAQs</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Elections</h4><ul><li><a href='/frmGenericPage.aspx?PageID=3051'>General Elections</a></li><li><a href='/frmGenericPage.aspx?PageID=3043'>LG Elections</a></li><li><a href='/frmGenericPage.aspx?PageID=27'>Election Laws</a></li><li><a href='/frmGenericPage.aspx?PageID=26'>Delimitation</a></li><li><a href='/frmGenericPage.aspx?PageID=3047'>Electoral Rolls</a></li><li><a href='/frmGenericPage.aspx?PageID=3104'>Party Position</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Media ECP</h4><ul><li><a href='/PressReleases.aspx'>Press Releases</a></li><li><a href='/Newsletters.aspx'>Newsletters/Publications</a></li><li><a href='/Notifications.aspx'>Notifications</a></li><li><a href='/frmEventsGallery.aspx'>Image Gallery</a></li><li><a href='/frmvideogallery.aspx'>Video Gallery</a></li><li><a href='/frmGenericPage.aspx?PageID=3157'>Training Material</a></li></ul></div></div><div class='span2'><div class='box-1'><h4>Misc.</h4><ul><li><a href='/frmGenericPage.aspx?PageID=28'>Tenders</a></li><li><a href='/frmGenericPage.aspx?PageID=3148'>Contact Us</a></li><li><a href='https://www.ecp.gov.pkcontact.pdf'>ECP Secretariat Officers Contact Numbers</a></li></ul></div></div>
                            </div>
                        </div>
                    </div>
                    <!--Footer Top End-->
                    <!--Footer Copyright Start-->
                    <div class="footer-copyright"><strong class="copy">Copyright &copy; ECP 2018 - Election Commission of Pakistan.</strong></div>
                    <!--Footer Copyright End-->
                </section>
                <!--Footer End-->
            </div>

        </div>
        <!--Wrapper End-->
        <!--Jquery Js-->
        <script src="adminw/js/jquery.js" type="text/javascript"></script>
        <!--Bootstrap Js-->
        <script src="adminw/js/bootstrap.js" type="text/javascript"></script>
        <!--Upcoming News Times Js-->
        <script src="adminw/js/jquery.plugin.js"></script>
        <!--Upcoming News Times Js-->
        <script src="adminw/js/jquery.countdown.js"></script>
        <!--Bxslider Js-->
        <script src="adminw/js/jquery.bxslider.min.js"></script>
        <!--Filterable JS-->
        <script type="text/javascript" src="adminw/js/jquery-filterable.js"></script>
        <!--Flex Timeline JS-->
        <script type="text/javascript" src="adminw/js/jquery.flexisel.js"></script>
        <!--Pretty Photo Js-->
        <script src="adminw/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
        <!-- Style Switcher -->
        <script type="text/javascript" src="adminw/js/styleswitch.js"></script>
        <script type="text/javascript" src="adminw/js/jquery.tabSlideOut.v1.3.js"></script>
        <!--Costom Js-->
        <script src="adminw/js/custom.js" type="text/javascript"></script>
<div class="addthis_sharing_toolbox"> </div>
            <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-55f3af0d2d622184" async="async"></script>
        </div>
    

<script type="text/javascript">
//<![CDATA[
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadSlider, {"_accessKey":"","_appendDataBoundItems":false,"_enableServerSideRendering":true,"_height":"22px","_itemBinding":{},"_renderLargeTicks":false,"_renderSmallTicks":false,"_selectedRegionStartValue":0,"_skin":"Default","_tabIndex":0,"_uniqueID":"ctl00$ContentPlaceHolder1$RadMediaPlayer1$Toolbar$ProgressRail","_width":"50px","clientStateFieldID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail_ClientState","itemData":[],"showDecreaseHandle":false,"showIncreaseHandle":false,"smallChange":0.01}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_ProgressRail"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadSlider, {"_accessKey":"","_appendDataBoundItems":false,"_enableServerSideRendering":true,"_height":"80px","_itemBinding":{},"_renderLargeTicks":false,"_renderSmallTicks":false,"_selectedRegionStartValue":0,"_skin":"Default","_tabIndex":0,"_uniqueID":"ctl00$ContentPlaceHolder1$RadMediaPlayer1$Toolbar$VolumeControl","_width":"22px","clientStateFieldID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl_ClientState","isDirectionReversed":true,"itemData":[],"orientation":1,"showDecreaseHandle":false,"showIncreaseHandle":false}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1_Toolbar_VolumeControl"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadAjaxLoadingPanel, {"backgroundTransparency":100,"initialDelayTime":0,"isSticky":false,"minDisplayTime":0,"skin":"Default","uniqueID":"ctl00$ContentPlaceHolder1$RadMediaPlayer1$LoadingIndicator","zIndex":90000}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1_LoadingIndicator"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadListView, {"UniqueID":"ctl00$ContentPlaceHolder1$RadMediaPlayer1$Playlist","_clientSettings":{"DataBinding":{"ItemPlaceHolderID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_itemPlaceholder","DataService":{}}},"_virtualItemCount":20,"clientStateFieldID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist_ClientState","renderMode":1}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1_Playlist"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadSocialShare, {"_addFbScript":false,"_addGoogleScript":false,"_addLinkedInScript":false,"_addPinterestScript":false,"_addTwitterScript":false,"_addYammerScript":false,"_locale":"en_US","_uniqueId":"ctl00$ContentPlaceHolder1$RadMediaPlayer1$Titlebar$SocialShare","clientStateFieldID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialShare_ClientState","mainButtons":"[['GoogleBookmarks','','', '470', '470', '', ''],['ShareOnFacebook','','', '470', '470', '', ''],['ShareOnTwitter','','', '470', '470', '', ''],['Digg','','', '470', '470', '', ''],['Tumblr','','', '470', '470', '', ''],['StumbleUpon','','', '470', '470', '', ''],['Reddit','','', '470', '470', '', ''],['LinkedIn','','', '470', '470', '', ''],['Delicious','','', '470', '470', '', ''],['Blogger','','', '470', '470', '', ''],['MySpace','','', '470', '470', '', ''],['GoogleBookmarks','','', '470', '470', '', ''],['MailTo','','', '470', '470', '', '']]"}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1_Titlebar_SocialShare"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadMediaPlayer, {"_mediaFilesData":[{"startVolume":-1,"startTime":0,"path":"Images/nvd2017c.mp4","title":"National Voters Day 2017 Video","autoPlay":false,"poster":"Thumnails/nvdpic.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/womennictvc.mp4","title":"Women NIC Registration","autoPlay":false,"poster":"Thumnails/womennicregistrationpic.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Register%20yourself%20as%20voter.mp4","title":"Register yourself as Voter","autoPlay":false,"poster":"Thumnails/53A6436D-9F87-47BC-B077-D0E5A69AA377.jpeg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/IMG_0219.MP4","title":"Register your vote - 24th April (Last date)","autoPlay":false,"poster":"Thumnails/E3C9B6F0-E930-45FD-85E0-89903CD06588.jpeg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/VID-20171110-WA0022.mp4","title":"Hon\u0027ble CEC addressing NADRA and ECP officials","autoPlay":false,"poster":"Thumnails/IMG_20171110_180047.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Video%20-%20Movie%201%20(2).mp4","title":"Hon\u0027ble Chief Election Commissioner speech on National Voters Day 2016","autoPlay":false,"poster":"Thumnails/VNDCEC.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Video%20-%20Movie%201%20(3).mp4","title":"President of Pakistan speech on National Voters Day 2016","autoPlay":false,"poster":"Thumnails/VNDPresident.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Video%20-%20Movie%201%20(1).mp4","title":"Secretary Election Commission of Pakistan speech on National Voters Day 2016","autoPlay":false,"poster":"Thumnails/VNDSecretary.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"images/Punjab.mp4","title":"Training Video for Polling Staff - LG Elections Punjab","autoPlay":false,"poster":"images/punjab.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"images/Sindh.mp4","title":"Training Video for Polling Staff - LG Elections Sindh","autoPlay":false,"poster":"images/Sindh.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/EVMPashto.mp4","title":"Electronic Voting Machine Video - Pashto","autoPlay":false,"poster":"Thumnails/evnpashto.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/EVMUrdu.mp4","title":"Electronic Voting Machine Video - Urdu","autoPlay":false,"poster":"Thumnails/evnpashto.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/voterday.mp4","title":"Seminar on Voter\u0027s Day 17 October 2012 at ECP Secretariat","autoPlay":false,"poster":"Thumnails/Voter-Day.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/2012_10_17_09_05_53.mp4","title":"Hon\u0027ble Chief Justice of Pakistan checking his vote - 17th October 2012 at ECP Secretariat","autoPlay":false,"poster":"Thumnails/2012_10_17_09_05_53.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/DG-IT%20Interview%20Geo%20News%209pm%20Bulletin%20-%2029th%20february%202012.mp4","title":"Voter SMS Inauguration - 29th february 2012","autoPlay":false,"poster":"Thumnails/DG-IT%20Interview%20Geo%20News%209pm%20Bulletin%20-%2029th%20february.jpeg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Final-Video,%2021-7-2017.mp4","title":"ECP Awards Ceremony","autoPlay":false,"poster":"Thumnails/certificate-distribution.jpg","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/Highest%20Social%20Service%20Award%20(Clip).mp4","title":"Highest Social Service Award - 17th October 2012 at ECP Secretariat","autoPlay":false,"poster":"Thumnails/Highest-Social-Service-Awar.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/howtovote.mp4","title":"How to cast a vote... 2008","autoPlay":false,"poster":"Thumnails/howtovote.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/InterView,Awards.mp4","title":"Interview of DG-IT ECP, ICPS Award 2013","autoPlay":false,"poster":"Thumnails/InterView,Awards.png","sources":[]},{"startVolume":-1,"startTime":0,"path":"Images/IMG_2887.mp4","title":"ICPS Innovative use of Technology Award 2013 ","autoPlay":false,"poster":"Thumnails/IMG_2887.png","sources":[]}],"clientStateFieldID":"ctl00_ContentPlaceHolder1_RadMediaPlayer1_ClientState","options":{"uniqueID":"ctl00$ContentPlaceHolder1$RadMediaPlayer1","hdActive":false,"fsActive":false,"startVolume":50,"muted":false,"toolbarDocked":false,"volumeButtonToolTip":"Mute","fullScreenButtonToolTip":"Full Screen","hdButtonToolTip":"HD","_renderMode":"Classic","_flashModuleUrl":"/WebResource.axd?d=ufF89YVX-wls0Xo5xoAI3VmxKQzaAVkW1Vbws7HsE-bpk_HDvnYuVN70bHXM2Et1QCj4dHf7S5L5e0BVDIfivsdkY0limAaWuDHq9xPJA3fEdnvSl2s9oqBHe7s5I7fyggsG0fSDGS7ifiuu8LkqsGWSSolHr6ty3_Xfbp5Ccv41\u0026t=635779927213250000","playlistPosition":"Horizontal","playlistButtonsTrigger":"Hover"}}, null, null, $get("ctl00_ContentPlaceHolder1_RadMediaPlayer1"));
});
//]]>
</script>
</form>
</body>
</html>
