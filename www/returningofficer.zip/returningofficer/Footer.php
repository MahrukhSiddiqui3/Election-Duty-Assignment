
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    
    </div>
    <strong>Copyright 2017-2018 <a href="https://adminlte.io">ELECTION COMMISSION OF PAKISTAN</a>.</strong> All rights
    reserved.
  </footer>